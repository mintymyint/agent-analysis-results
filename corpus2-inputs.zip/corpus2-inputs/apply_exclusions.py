#!/usr/bin/env python3
"""Apply the pre-registered prompt exclusion, between stage 5 and stage 6.

What it does
------------
Reads data/excluded_prompts.v1.json -- the frozen list of prompt hashes to drop,
with the grounds recorded in the file -- and removes those rows from
out/tasks.csv, keeping them in out/tasks_excluded.csv for the record.

Everything downstream then follows without any change to the pipeline:

  * Stage 6 asks for coding only on the prompts that remain.
  * Stage 9 joins runs to prompts on the hash, so runs whose prompt is gone fall
    out and are counted in the 'excluded before any statistic' line it already
    prints. That is an existing, reported exclusion path, not a hack.
  * Stage 7 still measures every run. Harmless: the analysis reads only the runs
    it can join to a prompt.

Keyed on task_sha256, NEVER on task_id -- ids are assigned per corpus in sha
order and name a different prompt in each.

Usage::

    python3 apply_exclusions.py --out out          # dry run, prints the effect
    python3 apply_exclusions.py --out out --write

Idempotent: running it twice is a no-op with a note, not a double removal.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path

SHA_RE = re.compile(r"^[0-9a-f]{64}$")


def read_csv(path: Path) -> tuple[list[str], list[dict]]:
    with open(path, newline="", encoding="utf-8") as fh:
        r = csv.DictReader(fh)
        return list(r.fieldnames or []), list(r)


def write_csv(path: Path, cols: list[str], rows: list[dict]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
    tmp.replace(path)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Remove the pre-registered excluded prompts from tasks.csv.")
    ap.add_argument("--out", default="out")
    ap.add_argument("--rule", default="data/excluded_prompts.v1.json")
    ap.add_argument("--write", action="store_true",
                    help="actually modify out/tasks.csv; otherwise dry run")
    args = ap.parse_args(argv)

    out = Path(args.out)
    rule_path = Path(args.rule)
    tasks_path = out / "tasks.csv"
    kept_path = out / "tasks_excluded.csv"

    if not rule_path.is_file():
        print(f"exclusion rule not found: {rule_path}", file=sys.stderr)
        return 2
    if not tasks_path.is_file():
        print(f"{tasks_path} not found -- run stage 5 first.", file=sys.stderr)
        return 2

    rule = json.loads(rule_path.read_text(encoding="utf-8"))
    entries = rule.get("excluded") or []
    bad = [e.get("task_sha256", "") for e in entries
           if not SHA_RE.match(str(e.get("task_sha256", "")))]
    if bad:
        print("the rule file contains something that is not a sha256:",
              file=sys.stderr)
        for b in bad:
            print(f"  {b!r}", file=sys.stderr)
        return 2
    drop = {e["task_sha256"]: e for e in entries}

    cols, rows = read_csv(tasks_path)
    present = {r.get("task_sha256", "") for r in rows}

    print("=" * 76)
    print("PRE-REGISTERED PROMPT EXCLUSION")
    print("=" * 76)
    print(f"  rule      {rule_path}  (version {rule.get('version')}, "
          f"decided {rule.get('decided')})")
    print(f"  tasks.csv {tasks_path}  ({len(rows)} prompts)")
    print()
    print("  GROUNDS, as recorded in the rule file:")
    for line in (rule.get("grounds") or "").split(". "):
        if line.strip():
            print(f"    {line.strip().rstrip('.')}.")
    print()

    hit = [r for r in rows if r.get("task_sha256", "") in drop]
    keep = [r for r in rows if r.get("task_sha256", "") not in drop]
    missing = [s for s in drop if s not in present]

    if not hit and missing:
        print("  NOTHING TO DO.")
        if len(rows) == rule.get("expected_prompts_remaining"):
            print(f"  tasks.csv already holds {len(rows)} prompts and none of")
            print("  the excluded hashes are in it, so the rule has already")
            print("  been applied. Running this twice is safe.")
            return 0
        print("  None of the excluded hashes appear in tasks.csv, and the prompt")
        print("  count does not match what the rule expects either. Check that")
        print("  --out points at the right corpus before going on.")
        return 1

    print("  REMOVING")
    n_runs_dropped = 0
    for r in sorted(hit, key=lambda r: int(r["task_id"])):
        sha = r["task_sha256"]
        e = drop[sha]
        n = int(r.get("n_runs_total") or 0)
        n_runs_dropped += n
        print(f"    id {r['task_id']:>2}  {sha[:12]}  {n:>4} runs "
              f"({r.get('runs_per_agent', '')})")
        print(f"          {(r.get('task_text') or '')[:64]}")
        print(f"          superseded by {e['superseded_by_sha256'][:12]}, "
              f"which adds:")
        print(f"            \"{e['superseded_by_adds']}\"")
    print()

    if missing:
        print(f"  {len(missing)} hash(es) in the rule are NOT in this tasks.csv:")
        for s in missing:
            print(f"    {s[:12]}  (id {drop[s].get('task_id_in_this_corpus')} "
                  "in the corpus the rule was written against)")
        print("  Partly applied, or a different corpus. Look before writing.")
        print()

    expect = rule.get("expected_prompts_remaining")
    print("  RESULT")
    print(f"    prompts  {len(rows)} -> {len(keep)}"
          + (f"   (rule expects {expect})" if expect is not None else ""))
    print(f"    runs dropped from the analysed universe: {n_runs_dropped}")
    if expect is not None and len(keep) != expect:
        print()
        print(f"    MISMATCH: {len(keep)} prompts remain but the rule expects "
              f"{expect}.")
        print("    Not writing. Either this is not the corpus the rule was")
        print("    written for, or the corpus changed. Resolve that first --")
        print("    quietly analysing a different prompt set is the one outcome")
        print("    worth refusing.")
        return 1
    print()

    if not args.write:
        print("  DRY RUN -- nothing changed. Add --write to apply.")
        print("=" * 76)
        return 0

    write_csv(kept_path, cols, sorted(hit, key=lambda r: int(r["task_id"])))
    write_csv(tasks_path, cols, keep)
    print(f"  WROTE {tasks_path}         {len(keep)} prompts")
    print(f"  WROTE {kept_path}  {len(hit)} removed prompts, kept for the record")
    print()
    print("  task_id values now have gaps where the removed prompts were. That")
    print("  is fine -- everything downstream joins on the hash or sorts on the")
    print("  id, and nothing assumes they are contiguous.")
    print()
    print("  Report the exclusion in your results: 25 prompt texts collected,")
    print("  5 dropped, which five and why, and that the rule was fixed before")
    print("  any result. tasks_excluded.csv and the rule file are the record.")
    print("=" * 76)
    return 0


if __name__ == "__main__":
    sys.exit(main())
