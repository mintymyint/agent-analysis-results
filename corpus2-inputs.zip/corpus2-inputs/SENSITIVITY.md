# Primary and sensitivity analysis sets

Forty Hermes/SiliconFlow runs requested models other than the intended one
(13 on `moonshotai/Kimi-K3`, 27 on `zai-org/GLM-5.2`) during an episode of
configuration experimentation. **Nothing is deleted.** They are retained in the
collected corpus and in the sensitivity analysis, and excluded only from the
primary controlled comparison so that "model held constant" is true of the set
the RQ1 claims rest on.

## The results you already have ARE the sensitivity analysis

Everything currently in `out/` was computed over the unrestricted set — all
1,500 provider-scoped runs, including the 40. Do not recompute it. Snapshot it:

```sh
cd ~/corpus2-inputs
mkdir -p out_sensitivity
cp out/*.csv out/*.md out/*.json out_sensitivity/
```

That copies the result tables and leaves the `cache/pcap` shards where they are,
so nothing large is duplicated and stage 3 is never repeated.

## Then build the primary set

```sh
R=/Users/mintyy_thesis/collection
python3 select_models.py --out out            # dry run, read it
python3 select_models.py --out out --write
```

It reads the model each run requested from that run's own HTTP log, so it
re-derives the exclusion rather than trusting a list of run numbers. Removed rows
go to `out/runs_excluded_models.csv` with the model each requested.

Then re-run everything that reads `runs.csv`. **Stage 3 is not repeated.**

```sh
agentnet http-parse --root $R --out out
agentnet align --out out
agentnet tasks --out out
python3 apply_exclusions.py --out out --write
python3 install_coding_sheet.py --coded data/coding_draft.csv \
    --target-tasks out/tasks.csv --write out/task_coding_sheet.csv
agentnet taxonomy --out out
agentnet features --out out --allowlist data/provider_allowlist.v2.json
agentnet validate --out out
agentnet analyze --out out
```

`agentnet tasks` rewrites a **blank** coding sheet, which is why the re-install
step is not optional. `apply_exclusions.py` and `install_coding_sheet.py` both
refuse to clobber existing work, so if either stops with a refusal, delete the
file it names and re-run that one step.

## Then compare the two

```sh
python3 compare_sets.py --primary out --sensitivity out_sensitivity
```

Expected effect: Hermes loses 40 of 750 runs, all in the SiliconFlow cell. The
provider balance within Hermes goes from 375/375 to 335/375 — 47.2% against
52.8%, against OpenClaw's exact 50/50, a 2.8-point gap. Cell sizes drop by
roughly two runs per prompt if the 40 are spread evenly across prompts, which
the comparison will show.

## What to write

> Forty Hermes/SiliconFlow runs used unintended model configurations. These runs
> were retained in the collected corpus but excluded from the primary controlled
> analysis, which is therefore restricted to runs requesting the intended model.
> A sensitivity analysis over the unrestricted set was used to assess whether the
> restriction materially affected the findings.

Then state what the comparison showed. If the verdicts are unchanged, say so and
the restriction costs you nothing but a sentence. If any verdict moves, that is
itself worth reporting — it would mean 2.7% of runs on one side of the contrast
were carrying a result.

**One thing to be honest about in the text.** Unlike the provider-scope and
prompt-exclusion rules, this one was fixed *after* the first analysis of this
corpus had been computed. It rests on which model a run requested — a property of
collection, not an outcome — but the timing differs from the other two and the
write-up should say so rather than present all three as equally pre-registered.
`data/model_scope.v1.json` records this.
