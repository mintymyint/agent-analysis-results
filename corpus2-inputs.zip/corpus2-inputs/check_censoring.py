#!/usr/bin/env python3
"""Do flows close within the capture, or are their durations censored by it?

median_flow_duration_s measures first-packet to last-packet-seen. For a flow
still open when the capture stops, that is not a duration -- it is a lower
bound set by the capture. OpenClaw's captures run about twice as long as
Hermes's, so if OpenClaw also leaves proportionally more flows open, its
longer median could be an artefact of capture length rather than behaviour.

This counts, per capture: how many TCP streams exist, and how many were
closed with a FIN. Nothing is modified and nothing is written.
"""
import collections, csv, os, random, subprocess, sys

OUT = os.environ.get("AGENTNET_OUT", "out")
PER_AGENT = int(sys.argv[1]) if len(sys.argv) > 1 else 5
TSHARK = os.environ.get("TSHARK", "tshark")


def streams(path, display_filter=None):
    cmd = [TSHARK, "-r", path, "-T", "fields", "-e", "tcp.stream"]
    if display_filter:
        cmd += ["-Y", display_filter]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    except (OSError, subprocess.TimeoutExpired) as e:
        return None
    return {s.strip() for s in r.stdout.split("\n") if s.strip()}


rows = list(csv.DictReader(open(os.path.join(OUT, "runs.csv"),
                                newline="", encoding="utf-8")))
by_agent = collections.defaultdict(list)
for r in rows:
    p = r.get("pcap_path", "")
    if p and os.path.exists(p):
        by_agent[r.get("agent", "")].append((r["run_id"], p))

rng = random.Random(20260914)
print(f"sampling {PER_AGENT} captures per agent from {OUT}\n")
print(f"{'agent':10s} {'run':38s} {'streams':>8s} {'closed':>7s} {'closed %':>9s}")
totals = collections.defaultdict(lambda: [0, 0])
for agent in sorted(by_agent):
    picks = rng.sample(by_agent[agent], min(PER_AGENT, len(by_agent[agent])))
    for run_id, path in sorted(picks):
        alls = streams(path)
        fins = streams(path, "tcp.flags.fin==1")
        if alls is None or fins is None:
            print(f"{agent:10s} {run_id[:38]:38s}  tshark failed")
            continue
        n, c = len(alls), len(fins & alls)
        totals[agent][0] += n
        totals[agent][1] += c
        pct = (100.0 * c / n) if n else 0.0
        print(f"{agent:10s} {run_id[-38:]:38s} {n:8d} {c:7d} {pct:8.1f}%")

print()
print("POOLED OVER THE SAMPLED CAPTURES")
for agent in sorted(totals):
    n, c = totals[agent]
    print(f"  {agent:10s} {c:5d} of {n:5d} streams closed with a FIN "
          f"= {100.0*c/n if n else 0:.1f}%")
print()
print("Similar percentages -> censoring affects both agents alike, and the")
print("flow-duration difference is not explained by capture length.")
print("OpenClaw markedly lower -> more of its flows are still open at capture")
print("end, its durations are censored more often, and median_flow_duration_s")
print("cannot be separated from capture length.")
