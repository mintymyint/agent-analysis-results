#!/usr/bin/env python3
"""EXPLORATORY ANALYSIS — can task class be predicted from network features?

NOT part of the frozen analysis plan. This sits outside the pre-registered RQ1
and RQ2 analyses and must be reported in a separately labelled exploratory
chapter. It introduces machinery the plan does not admit, and nothing here may
be used to revise an RQ1 or RQ2 result.

The question
------------
RQ2 establishes that task class is associated with network behaviour. This asks
the stronger operational question: given only passively observable features of a
run, can the class of a prompt the model has NEVER SEEN be predicted? That is a
different and far more interesting claim than recognising repeated executions of
a known prompt.

Design
------
**The prompt is the independent unit.** There are 1,359 runs but only 20 distinct
prompts. Repeated runs sharpen the estimate of each prompt's behaviour; they are
not 1,359 independent opportunities to generalise to a new task.

**Leave-one-prompt-out cross-validation.** Every run of the held-out prompt, in
BOTH agents, is in the test fold. Imputation and standardisation are fitted on
the training folds only, inside an sklearn Pipeline, so no test information
reaches the fit. No feature selection is performed at all: the feature set is
fixed in advance and identical in every fold.

**Prompt-level performance is the primary result.** Each held-out prompt's runs
are aggregated into one prediction by mean predicted probability. Run-level
accuracy is reported as a secondary figure. Baselines are computed separately
for prompt-weighted and run-weighted evaluation, because the class balance
differs between them.

**Regularised multinomial logistic regression is the primary model.** A
depth-limited decision tree is available as a sensitivity analysis only. The
regularisation strength is FIXED a priori and is not tuned against the reported
metric; tuning it on the output of this script would invalidate the result.

**A permutation test is run by default.** At twenty prompts an accuracy figure
alone is not interpretable — the prompt labels are shuffled and the whole
cross-validation repeated, giving the distribution of accuracy under no real
association. Disable with ``--permutations 0`` if you must, but then do not
report the accuracy without some other error bar.

Usage::

    python3 classify_task_class.py --out out
    python3 classify_task_class.py --out out --model tree      # sensitivity
    python3 classify_task_class.py --out out --write-dir out/exploratory

Requires scikit-learn: ``python3 -m pip install --user scikit-learn``
"""

from __future__ import annotations

import argparse
import collections
import csv
import json
import sys
from pathlib import Path

#: The eleven features the frozen plan carries RQ2 claims on. FIXED. Changing
#: this set after seeing a result is feature selection on the test metric.
DEFAULT_FEATURES = [
    "longest_gap_s", "iat_down_median_ms", "bytes_up_total", "bytes_down_total",
    "bytes_ratio_down_up", "pktsize_up_median", "pktsize_down_median",
    "n_flows_tcp", "median_flow_duration_s", "distinct_dst_ips",
    "nonprovider_bytes_frac",
]
DEFAULT_CLASSES = ["local_execution", "web_only", "web_then_local"]


def read_csv(path: Path) -> list:
    if not path.is_file():
        raise SystemExit(f"not found: {path}")
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def load(out: Path, features, classes):
    """run-level matrix X, class labels y, prompt ids g, agent labels a."""
    tasks = read_csv(out / "tasks.csv")
    factors = read_csv(out / "task_factor_matrix.csv")
    run_tasks = read_csv(out / "run_tasks.csv")
    feats = read_csv(out / "run_features.csv")

    sha_to_task = {r["task_sha256"]: r["task_id"] for r in tasks
                   if r.get("task_sha256")}
    task_class = {r["task_id"]: r.get("taxonomy_class", "") for r in factors}
    run_to_task = {}
    for r in run_tasks:
        if (r.get("parse_status") or "ok") != "ok":
            continue
        t = sha_to_task.get(r.get("task_sha256", ""))
        if t is not None:
            run_to_task[r["run_id"]] = t

    X, y, g, a, skipped = [], [], [], [], collections.Counter()
    for r in feats:
        t = run_to_task.get(r.get("run_id"))
        if t is None:
            skipped["no_task"] += 1
            continue
        cls = task_class.get(t, "")
        if cls not in classes:
            skipped["no_class"] += 1
            continue
        row = []
        for f in features:
            v = (r.get(f) or "").strip()
            try:
                row.append(float(v)) if v else row.append(float("nan"))
            except ValueError:
                row.append(float("nan"))
        X.append(row); y.append(cls); g.append(t); a.append(r.get("agent", ""))
    return X, y, g, a, skipped


def build_model(kind: str, C: float, seed: int, balanced: bool):
    from sklearn.pipeline import Pipeline
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler
    cw = "balanced" if balanced else None
    if kind == "logreg":
        from sklearn.linear_model import LogisticRegression
        # L2 is the default in every sklearn version; naming `penalty`
        # explicitly is deprecated from 1.8, so it is omitted for
        # forward and backward compatibility.
        clf = LogisticRegression(C=C, max_iter=5000,
                                 class_weight=cw, random_state=seed)
    elif kind == "tree":
        from sklearn.tree import DecisionTreeClassifier
        clf = DecisionTreeClassifier(max_depth=3, min_samples_leaf=20,
                                     class_weight=cw, random_state=seed)
    else:
        raise SystemExit(f"unknown --model {kind}")
    return Pipeline([
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
        ("clf", clf),
    ])


def run_cv(X, y, g, a, classes, kind, C, seed, balanced):
    """Leave-one-prompt-out CV. Returns per-prompt and per-run predictions."""
    import numpy as np
    X = np.asarray(X, dtype=float)
    y = np.asarray(y)
    g = np.asarray(g)
    a = np.asarray(a)
    prompts = sorted(set(g.tolist()), key=lambda t: int(t) if str(t).isdigit() else t)

    prompt_pred, run_true, run_pred, cell_pred = {}, [], [], {}
    for held in prompts:
        te = g == held
        tr = ~te
        if len(set(y[tr].tolist())) < 2:
            continue
        model = build_model(kind, C, seed, balanced)
        model.fit(X[tr], y[tr])
        cls_order = list(model.named_steps["clf"].classes_)
        proba = model.predict_proba(X[te])
        # prompt-level: mean predicted probability over every run of the prompt,
        # both agents pooled
        prompt_pred[held] = cls_order[int(np.argmax(proba.mean(axis=0)))]
        # per agent, same aggregation within the agent's runs
        for ag in sorted(set(a[te].tolist())):
            m = a[te] == ag
            if m.sum():
                cell_pred[(held, ag)] = cls_order[int(np.argmax(proba[m].mean(axis=0)))]
        run_true.extend(y[te].tolist())
        run_pred.extend([cls_order[i] for i in proba.argmax(axis=1)])
    return prompt_pred, cell_pred, run_true, run_pred


def metrics(true_map, pred_map, classes):
    """Accuracy, balanced accuracy (macro recall), per-class recall, confusion."""
    keys = [k for k in pred_map if k in true_map]
    n = len(keys)
    correct = sum(1 for k in keys if pred_map[k] == true_map[k])
    conf = {t: collections.Counter() for t in classes}
    for k in keys:
        conf[true_map[k]][pred_map[k]] += 1
    recall = {}
    for c in classes:
        tot = sum(conf[c].values())
        recall[c] = (conf[c][c] / tot) if tot else None
    got = [v for v in recall.values() if v is not None]
    return {
        "n": n,
        "accuracy": correct / n if n else None,
        "balanced_accuracy": sum(got) / len(got) if got else None,
        "recall": recall,
        "confusion": conf,
        "correct": correct,
    }


def print_confusion(conf, classes, title):
    print(f"  {title}")
    w = max(len(c) for c in classes) + 2
    print("    " + " " * w + "".join(f"{c[:12]:>14}" for c in classes)
          + f"{'recall':>9}")
    for t in classes:
        row = [conf[t][p] for p in classes]
        tot = sum(row)
        r = f"{row[classes.index(t)]/tot:.0%}" if tot else "n/a"
        print(f"    {t:<{w}}" + "".join(f"{v:>14}" for v in row) + f"{r:>9}")
    print(f"    {'(rows = true class, columns = predicted)':<{w}}")
    print()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="EXPLORATORY: predict task class from network features, "
                    "leave-one-prompt-out.")
    ap.add_argument("--out", default="out", help="the FROZEN primary dataset")
    ap.add_argument("--features", default=",".join(DEFAULT_FEATURES),
                    help="fixed feature set; do not change it after seeing a result")
    ap.add_argument("--classes", default=",".join(DEFAULT_CLASSES))
    ap.add_argument("--agents", default=None,
                    help="restrict to these agents (default: all present)")
    ap.add_argument("--model", default="logreg", choices=("logreg", "tree"),
                    help="logreg is primary; tree is a sensitivity analysis only")
    ap.add_argument("--C", type=float, default=1.0,
                    help="L2 strength, FIXED a priori. Tuning this against the "
                         "reported accuracy invalidates the result.")
    ap.add_argument("--no-class-weight", action="store_true",
                    help="disable balanced class weighting (default: enabled, "
                         "chosen a priori for the 6/6/8 imbalance)")
    ap.add_argument("--permutations", type=int, default=1000,
                    help="label-permutation null. 0 disables; then report no "
                         "accuracy without some other error bar. Each "
                         "permutation repeats the whole CV, so 1000 takes "
                         "roughly five to ten minutes.")
    ap.add_argument("--seed", type=int, default=20260914)
    ap.add_argument("--write-dir", default=None,
                    help="also write per-prompt predictions and the confusion "
                         "matrix as CSV")
    args = ap.parse_args(argv)

    try:
        import numpy as np
        import sklearn  # noqa: F401
    except ImportError:
        print("scikit-learn and numpy are required:", file=sys.stderr)
        print("  python3 -m pip install --user scikit-learn", file=sys.stderr)
        return 2

    out = Path(args.out)
    features = [f.strip() for f in args.features.split(",") if f.strip()]
    classes = [c.strip() for c in args.classes.split(",") if c.strip()]

    X, y, g, a, skipped = load(out, features, classes)
    if args.agents:
        keep = {s.strip() for s in args.agents.split(",")}
        idx = [i for i, ag in enumerate(a) if ag in keep]
        X = [X[i] for i in idx]; y = [y[i] for i in idx]
        g = [g[i] for i in idx]; a = [a[i] for i in idx]
    if not X:
        print("no usable rows", file=sys.stderr)
        return 2

    true_map = {}
    for cls, t in zip(y, g):
        true_map[t] = cls
    prompts = sorted(true_map, key=lambda t: int(t) if str(t).isdigit() else t)
    per_class_prompts = collections.Counter(true_map.values())
    per_class_runs = collections.Counter(y)

    print("=" * 84)
    print("EXPLORATORY ANALYSIS — TASK-CLASS PREDICTION FROM NETWORK FEATURES")
    print("=" * 84)
    print("  NOT part of the frozen analysis plan. Report in a separately")
    print("  labelled exploratory chapter; nothing here may revise RQ1 or RQ2.")
    print()
    print(f"  dataset     {out}")
    print(f"  runs        {len(X)}")
    print(f"  prompts     {len(prompts)}   (the independent unit)")
    print(f"  agents      {', '.join(sorted(set(a)))}")
    print(f"  features    {len(features)} fixed: {', '.join(features)}")
    print(f"  model       {args.model}"
          + (f", L2 C={args.C} (fixed a priori)" if args.model == "logreg"
             else ", depth 3, min leaf 20 — SENSITIVITY ONLY"))
    print(f"  weighting   {'balanced' if not args.no_class_weight else 'none'}")
    print(f"  validation  leave-one-prompt-out; all runs of the held-out prompt,")
    print(f"              both agents, in the test fold; imputation and scaling")
    print(f"              fitted on training folds only; no feature selection")
    if skipped:
        print(f"  skipped     {dict(skipped)}")
    print()
    print("  CLASS BALANCE")
    for c in classes:
        print(f"    {c:<18}{per_class_prompts.get(c,0):>4} prompts"
              f"{per_class_runs.get(c,0):>8} runs")
    print()

    maj_p = max(per_class_prompts.values()) / len(prompts)
    maj_r = max(per_class_runs.values()) / len(y)
    print("  BASELINES (majority class)")
    print(f"    prompt-weighted  {maj_p:.1%}   "
          f"({max(per_class_prompts, key=per_class_prompts.get)})")
    print(f"    run-weighted     {maj_r:.1%}   "
          f"({max(per_class_runs, key=per_class_runs.get)})")
    print(f"    balanced accuracy of any constant predictor: "
          f"{1/len(classes):.1%}")
    print()

    pp, cp, rt, rp = run_cv(X, y, g, a, classes, args.model, args.C,
                            args.seed, not args.no_class_weight)
    m = metrics(true_map, pp, classes)

    print("=" * 84)
    print("PRIMARY RESULT — PROMPT LEVEL")
    print("=" * 84)
    print(f"  {m['correct']} of {m['n']} held-out prompts classified correctly")
    print(f"  accuracy            {m['accuracy']:.1%}   "
          f"(baseline {maj_p:.1%})")
    print(f"  balanced accuracy   {m['balanced_accuracy']:.1%}   "
          f"(baseline {1/len(classes):.1%})")
    print()
    print("  PER-CLASS RECALL")
    for c in classes:
        r = m["recall"][c]
        print(f"    {c:<18}{'n/a' if r is None else f'{r:.0%}':>6}"
              f"   ({per_class_prompts.get(c,0)} prompts)")
    print()
    print_confusion(m["confusion"], classes, "CONFUSION MATRIX (prompts)")

    if args.permutations > 0:
        import numpy as np
        rng = np.random.default_rng(args.seed)
        base = m["accuracy"]
        labels = [true_map[t] for t in prompts]
        ge = 0
        for _ in range(args.permutations):
            perm = list(labels)
            rng.shuffle(perm)
            shuffled = dict(zip(prompts, perm))
            y2 = [shuffled[t] for t in g]
            pp2, _, _, _ = run_cv(X, y2, g, a, classes, args.model, args.C,
                                  args.seed, not args.no_class_weight)
            m2 = metrics(shuffled, pp2, classes)
            if m2["accuracy"] is not None and m2["accuracy"] >= base:
                ge += 1
        p = (ge + 1) / (args.permutations + 1)
        print("  PERMUTATION TEST (prompt labels shuffled, whole CV repeated)")
        print(f"    {args.permutations} permutations, "
              f"{ge} reached or beat {base:.1%}")
        print(f"    p = {p:.4f}")
        print("    This is the error bar on the accuracy above. At twenty")
        print("    prompts, an accuracy without one is not interpretable.")
        print()

    agents = sorted(set(a))
    if len(agents) > 1:
        print("  SECONDARY — PER AGENT (same folds, prediction aggregated")
        print("  within each agent's runs of the held-out prompt)")
        for ag in agents:
            sub = {t: v for (t, A), v in cp.items() if A == ag}
            ma = metrics(true_map, sub, classes)
            print(f"    {ag:<10}{ma['correct']}/{ma['n']} correct   "
                  f"accuracy {ma['accuracy']:.1%}   "
                  f"balanced {ma['balanced_accuracy']:.1%}")
        print()

    rt_map = {i: v for i, v in enumerate(rt)}
    rp_map = {i: v for i, v in enumerate(rp)}
    mr = metrics(rt_map, rp_map, classes)
    print("  SECONDARY — RUN LEVEL")
    print(f"    {mr['correct']} of {mr['n']} runs   accuracy {mr['accuracy']:.1%}"
          f"   (run-weighted baseline {maj_r:.1%})")
    print(f"    balanced accuracy {mr['balanced_accuracy']:.1%}")
    print("    Runs within a prompt are not independent. This figure describes")
    print("    the classifier's behaviour, not its ability to generalise to an")
    print("    unseen task; the prompt-level figure above is the result.")
    print()

    print("=" * 84)
    print("WHAT THIS DOES AND DOES NOT SUPPORT")
    print("=" * 84)
    print("  Supports: network metadata observable without decryption carries")
    print("  information about the CATEGORY of task an agent was given, on")
    print("  prompts the model never saw during training.")
    print()
    print("  Does NOT support a claim about a real passive adversary. The")
    print("  captures are whole-host, so features include traffic no adversary")
    print("  could attribute to the agent and some they could not see at all.")
    print("  Twenty prompts in three classes cannot establish generalisation to")
    print("  tasks beyond this set. Both agents ran one model on two providers")
    print("  from one host on one network. Treat this as evidence that the")
    print("  information is present, not as a demonstrated attack.")
    print("=" * 84)

    if args.write_dir:
        wd = Path(args.write_dir); wd.mkdir(parents=True, exist_ok=True)
        with open(wd / "task_class_predictions.csv", "w", newline="",
                  encoding="utf-8") as fh:
            w = csv.writer(fh, lineterminator="\n")
            w.writerow(["task_id", "true_class", "predicted_class", "correct"]
                       + [f"predicted_{ag}" for ag in agents])
            for t in prompts:
                w.writerow([t, true_map[t], pp.get(t, ""),
                            int(pp.get(t) == true_map[t])]
                           + [cp.get((t, ag), "") for ag in agents])
        with open(wd / "task_class_metrics.json", "w", encoding="utf-8") as fh:
            json.dump({
                "exploratory": True,
                "not_in_frozen_plan": True,
                "dataset": str(out), "model": args.model, "C": args.C,
                "features": features, "n_runs": len(X), "n_prompts": len(prompts),
                "prompt_accuracy": m["accuracy"],
                "prompt_balanced_accuracy": m["balanced_accuracy"],
                "prompt_recall": m["recall"],
                "baseline_prompt_weighted": maj_p,
                "baseline_run_weighted": maj_r,
                "run_accuracy": mr["accuracy"],
                "permutations": args.permutations,
            }, fh, indent=2, sort_keys=True)
        print(f"\n  wrote {wd}/task_class_predictions.csv and "
              f"task_class_metrics.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
