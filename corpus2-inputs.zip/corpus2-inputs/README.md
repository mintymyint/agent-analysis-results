# Corpus 2 — SiliconFlow / Together AI

Same pipeline as the OpenRouter run. The `agentnet` package is unchanged —
0.10.2, plan revision 7, same hash, 13 claim-carrying features, RQ1 on 9 and
RQ2 on 11. **RQ1 and RQ2 are unchanged.** No new feature, no new statistic, no
new threshold, and nothing in the package was edited.

This folder holds only what the OpenRouter corpus already had and this one does
not: a provider allowlist that covers these providers, a coded task sheet, and a
record of five prompts that have to come out. Three verification scripts are
here too, the same ones that ran on OpenRouter.

## Setup

```sh
cd ~
tar xzf ~/Downloads/corpus2-inputs.tar.gz
python3 -m pip install --user ~/Downloads/agentnet-0.10.2.tar.gz
python3 -m pip install --user numpy
cd ~/corpus2-inputs
```

Run everything from inside this folder — `data/` is referenced by relative path.
Needs `tshark` on PATH for stage 3.

If `agentnet` is not on PATH after installing (a `--user` install on macOS puts
it in `~/Library/Python/3.x/bin`, usually absent from PATH), replace `agentnet`
with `python3 -m agentnet.cli` in every command below. It is the same program.

## The commands

`R` is your corpus root — the parent of the agent folders:

```sh
R=/Users/mintyy_thesis/collection
```

Stages 1–3. The third is the hours-long tshark pass; `--resume` means a Ctrl-C
costs one run, not the stage.

```sh
agentnet index --root $R --out out
agentnet http-parse --root $R --out out
agentnet pcap-extract --root $R --out out --resume
```

Then check the allowlist actually covers what the captures contain — see
"The allowlist" below for why this one matters:

```sh
python3 sni_coverage_audit.py --out out --allowlist data/provider_allowlist.v2.json
```

Then restrict the corpus to the two intended providers. The tree also holds an
`openrouter` provider directory, which is not part of this corpus — see
"The provider scope" below:

```sh
python3 select_providers.py --out out          # dry run, shows what goes
python3 select_providers.py --out out --write
```

Re-run the stages that read `runs.csv` so the task set and the MITM parse agree
with the new scope. Stage 3 does **not** need re-running — the shards for the
dropped runs stay on disk and are never read again:

```sh
agentnet http-parse --root $R --out out
agentnet align --out out
agentnet tasks --out out
```

The two steps this corpus needs that OpenRouter did not — the prompt exclusion,
then the coded sheet:

```sh
python3 apply_exclusions.py --out out --write
python3 install_coding_sheet.py --coded data/coding_draft.csv \
    --target-tasks out/tasks.csv --write out/task_coding_sheet.csv
```

Stages 6–9:

```sh
agentnet taxonomy --out out
agentnet features --out out --allowlist data/provider_allowlist.v2.json
agentnet validate --out out
agentnet analyze --out out
```

Then the two checks that ran on OpenRouter:

```sh
python3 verify_independently.py --out out
AGENTNET_OUT=out python3 check_censoring.py 5
```

Results are in `out/results.md`. Note that stages 4 onwards take no `--root` —
they read what the earlier stages wrote.

## Why each of the three extra files exists

### The allowlist — `data/provider_allowlist.v2.json`

SNI is matched **exactly, not by suffix**. A provider reached on a hostname that
is not listed counts as *non-provider*, with no error raised anywhere, because a
missing host and a real third-party host are indistinguishable to the code. And
`nonprovider_bytes_frac` is PRIMARY for RQ2, so it would read near 1.0 and look
like a finding.

The OpenRouter allowlist would have hit exactly that here. It holds
`openrouter.ai` and `api.together.xyz`; Together's documented host is now
`api.together.ai`, and SiliconFlow publishes `api.siliconflow.cn` and
`api.siliconflow.com`. None of those three match under exact comparison.

v2 lists five hosts with each one's source recorded in the file. `openrouter.ai`
is kept rather than asserted — if nothing reaches it, the entry matches nothing
and changes no number. **v1 is untouched and remains the OpenRouter allowlist**;
re-running that corpus against v2 would change numbers already reported.

**Confirm the three added hosts against the `base_url` each agent was actually
configured with** before reporting anything involving `nonprovider_bytes_frac`.
They came from vendor documentation, not from your configs. `sni_coverage_audit.py`
reports which hostnames the captures contain, broken down per provider directory,
so you can check that the `silicon` runs really did reach a SiliconFlow host.
That report is a coverage check on the allowlist, never a source for it — the
list is not derived from the corpus it describes.

### The provider scope — `data/provider_scope.v1.json`

The corpus tree holds three provider directories, not two: `silicon` (750 runs),
`together_ai` (749) and `openrouter` (499). The third was found by the SNI
coverage audit after stage 3 and is not part of this corpus — the OpenRouter
platform has its own corpus and its own reported results.

Pooling all three would put provider identity into the RQ1 agent contrast with
no way to separate them afterwards. The scope rule keeps `silicon` and
`together_ai` and drops the rest, keyed on the provider **directory** a run was
collected under — not on the SNI hostnames its capture turned out to contain,
because filtering on observed hosts would make the corpus definition a function
of the captures it describes. (The audit found `openrouter.ai` in 518 runs while
the directory holds 499, so a few runs under the kept directories also reached
that host. Those runs stay in.)

`select_providers.py` prints the per-agent × provider table before and after,
including each agent's provider share. **Read that share.** RQ1 pools across
providers, so if both agents carry the same mix it adds within-agent variance
and nothing else; if the mix differs between them, provider varies together with
agent and an RQ1 difference cannot be separated from a provider difference. No
cutoff is applied — a threshold invented after seeing the corpus would be worth
nothing. Dropped rows go to `out/runs_excluded_providers.csv`.

### The exclusion — `data/excluded_prompts.v1.json`

25 prompt texts were collected, not 20. Twenty are byte-identical (SHA-256) to
the OpenRouter corpus. The other five are *earlier wordings* of five of those:
each was superseded during collection when a grounding instruction was added
("do not answer until you've actually fetched the page" or equivalent).
Collection began with the earlier form and, after roughly 14 runs per agent,
those five prompts were revised and collection continued. So each earlier form
has exactly 28 runs, 14 per agent, and appears only in the earliest part of the
corpus, while its replacement appears only afterwards and the fifteen untouched
prompts span the whole period.

Prompt identity is therefore confounded with collection time for those five and
only those five. The rule drops them. Cost: 140 of 1,999 runs, 7%. The remaining
20 match the OpenRouter prompt set exactly.

The grounds are recorded in the file, along with the fact that the rule was fixed
before any result for this corpus existed — the decision rests on the prompt
texts and on run counts, neither of which is a measured outcome. Removed rows are
kept in `out/tasks_excluded.csv`, and stage 9 reports the dropped runs on its own
"excluded before any statistic" line. **Report the exclusion and its cost in the
write-up**; the file is the evidence it was not chosen after seeing a result.

Two things it deliberately does not do. It does not merge each pair: they differ
precisely on `has_grounding_instruction`, one of the nine coded factors, so
merging would pool two different instructions and destroy that variable. And it
does not treat the pairs as an experiment on grounding instructions — tempting,
same task with and without, but the with/without split *is* the early/late
collection split, so nothing separates the instruction from the time.

### The coded sheet — `data/coding_draft.csv`

Your approved OpenRouter coding, carried across. The headline class column is the
6 `web_only` / 6 `local_execution` / 8 `web_then_local` split you approved; the
20 prompts here are byte-identical to those 20, so it transfers unchanged.

`install_coding_sheet.py` joins it on `task_sha256`, never on `task_id` — ids are
assigned per corpus in hash order and name a different prompt in each. Ten of the
twenty carry a different id here than they did there, so a hand copy would have
assigned the wrong class to the wrong prompt and passed stage 6's validation
while doing it.

**Two columns are not carried over, and need your eye.** They did not exist in
that form when you approved the sheet, so there is no approved answer for them,
and the values in the file are mine — marked `coder=claude-draft-for-review`:

- `requires_artefact_creation` was added afterwards. 11 of 20 are 1. Code 1 when
  the task cannot be satisfied without leaving a written executable or content
  artefact behind; 0 when running something and reporting suffices with nothing
  left behind — `python --version`, a one-line shell command, listing a directory.
- `has_retrieval_dependency` was renamed from `has_data_dependency` and narrowed
  afterwards. Under the narrow reading 3 of 20 are 1: the trending-repos one
  (which READMEs is decided by the first fetch), the issue-count branch one, and
  the PyPI one where the version found builds the next URL. The broad wording
  fired on eight tasks and merely relabelled the headline class, which is why it
  was narrowed.

Both are plain CSV columns. Change any row you read differently — your call wins,
and `data/task_coding_rubric.md` is the rubric.

## Still open from the OpenRouter corpus, and it applies here too

`median_flow_duration_s` carries no claim until the censoring question is
answered. Flow duration is first packet to last packet *seen*, so a flow still
open when the capture stops has a lower bound rather than a duration.
`check_censoring.py` counts TCP streams against FIN-closed streams on five
captures per agent. Similar percentages across agents and the feature survives;
one agent markedly lower and it gets demoted, the way the connection-churn rate
was.

## Files

```
select_providers.py                 restricts the corpus to silicon + together_ai
select_models.py                    restricts the PRIMARY set to the intended model
compare_sets.py                     primary vs sensitivity, verdict by verdict
classify_task_class.py              EXPLORATORY: task-class prediction (not in the plan)
apply_exclusions.py                 applies the prompt exclusion to out/tasks.csv
install_coding_sheet.py             joins the coded sheet on by prompt hash
sni_coverage_audit.py               is the allowlist complete for this corpus?
verify_independently.py             recomputes the numbers, sharing no code
check_censoring.py                  the open flow-duration question
data/provider_scope.v1.json         which provider directories are in scope
data/model_scope.v1.json            the primary-set model restriction
data/provider_allowlist.v2.json     five hosts, each with its source
data/excluded_prompts.v1.json       which five prompts come out, and why
data/coding_draft.csv               the carried-over coding
data/task_coding_rubric.md          what each column means
```
