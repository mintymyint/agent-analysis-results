import collections, csv, statistics, sys
out = sys.argv[1] if len(sys.argv) > 1 else "out"
P = lambda n: f"{out}/{n}"
sha = {r['task_sha256']: r['task_id'] for r in csv.DictReader(open(P('tasks.csv')))}
r2t = {}
for r in csv.DictReader(open(P('run_tasks.csv'))):
    t = sha.get(r.get('task_sha256', ''))
    if t is not None:
        r2t[r['run_id']] = t
FEATS = ('nonprovider_bytes_frac', 'classifiable_byte_frac',
         'bytes_down_total', 'bytes_up_total')
cells = collections.defaultdict(lambda: collections.defaultdict(list))
for r in csv.DictReader(open(P('run_features.csv'))):
    t = r2t.get(r['run_id'])
    if t is None:
        continue
    for f in FEATS:
        v = (r.get(f) or '').strip()
        if v:
            cells[f][(t, r['agent'])].append(float(v))

def delta(xs, ys):
    gt = sum(1 for x in xs for y in ys if x > y)
    lt = sum(1 for x in xs for y in ys if x < y)
    n = len(xs) * len(ys)
    return (gt - lt) / n if n else 0.0

print(f"{'feature':<24}{'hermes':>12}{'openclaw':>12}{'med d':>9}{'same dir':>10}")
print("-" * 67)
for f in FEATS:
    if f not in cells:
        print(f"{f:<24}   not present in run_features.csv")
        continue
    tasks = sorted({t for t, _ in cells[f]}, key=lambda t: int(t))
    mh, mo, ds = [], [], []
    for t in tasks:
        xh, xo = cells[f].get((t, 'hermes'), []), cells[f].get((t, 'openclaw'), [])
        if not xh or not xo:
            continue
        mh.append(statistics.median(xh)); mo.append(statistics.median(xo))
        ds.append(delta(xh, xo))
    if not ds:
        continue
    pos = sum(1 for d in ds if d > 0); neg = sum(1 for d in ds if d < 0)
    print(f"{f:<24}{statistics.median(mh):>12.6g}{statistics.median(mo):>12.6g}"
          f"{statistics.median(ds):>9.3f}{f'{max(pos,neg)}/{len(ds)}':>10}")
