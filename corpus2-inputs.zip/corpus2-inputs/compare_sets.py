#!/usr/bin/env python3
"""Compare the primary and sensitivity analysis sets.

The primary set restricts to runs requesting the intended model; the sensitivity
set is the unrestricted one. Both are produced by the same frozen plan, so this
compares like with like and asks one question: did restricting the set change
any conclusion?

No new statistic is computed. It reads what Stage 9 already wrote in each
directory and puts the two side by side.

    python3 compare_sets.py --primary out --sensitivity out_sensitivity

Reads CSVs and the analyze quality report. Writes nothing.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path


def read_csv(path: Path):
    if not path.is_file():
        return []
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def num(v):
    v = (v or "").strip()
    try:
        return float(v)
    except ValueError:
        return None


def fmt(x, nd=3):
    return "n/a" if x is None else f"{x:.{nd}f}"


def coverage(out: Path) -> dict:
    p = out / "quality_report.analyze.json"
    if not p.is_file():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8")).get("coverage", {})
    except (OSError, ValueError):
        return {}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Primary vs sensitivity analysis set, verdict by verdict.")
    ap.add_argument("--primary", default="out")
    ap.add_argument("--sensitivity", default="out_sensitivity")
    args = ap.parse_args(argv)

    P, S = Path(args.primary), Path(args.sensitivity)
    for p in (P, S):
        if not (p / "rq1_summary.csv").is_file():
            print(f"{p / 'rq1_summary.csv'} not found.", file=sys.stderr)
            return 2

    print("=" * 92)
    print("PRIMARY vs SENSITIVITY")
    print("=" * 92)
    print(f"  primary      {P}   model held constant")
    print(f"  sensitivity  {S}   unrestricted")
    print()

    cp, cs = coverage(P), coverage(S)
    if cp and cs:
        print("A. COVERAGE")
        print(f"  {'':<22}{'primary':>12}{'sensitivity':>14}{'delta':>9}")
        for label, key in (("runs analysed", "n_runs"),
                           ("prompts", "n_tasks"),
                           ("cells", "n_cells")):
            a, b = cp.get(key), cs.get(key)
            if a is not None and b is not None:
                print(f"  {label:<22}{a:>12}{b:>14}{a - b:>+9}")
        for ag in sorted(set(cp.get("runs_per_agent", {}))
                         | set(cs.get("runs_per_agent", {}))):
            a = cp.get("runs_per_agent", {}).get(ag, 0)
            b = cs.get("runs_per_agent", {}).get(ag, 0)
            print(f"  {'runs: ' + ag:<22}{a:>12}{b:>14}{a - b:>+9}")
        pm, sm = cp.get("runs_per_cell_min"), cs.get("runs_per_cell_min")
        if pm is not None and sm is not None:
            print(f"  {'smallest cell':<22}{pm:>12}{sm:>14}{pm - sm:>+9}")
        print()

    rp = {r["feature"]: r for r in read_csv(P / "rq1_summary.csv")}
    rs = {r["feature"]: r for r in read_csv(S / "rq1_summary.csv")}
    feats = [f for f in rs if f in rp]

    print("B. RQ1 — did any verdict move?")
    print(f"  {'feature':<26}{'med d P':>10}{'med d S':>10}"
          f"{'>=med P/S':>12}{'verdict P':>14}{'verdict S':>14}  same?")
    print("  " + "-" * 90)
    moved = []
    for f in sorted(feats, key=lambda f: -abs(num(rs[f]["median_delta"]) or 0)):
        a, b = rp[f], rs[f]
        va, vb = a.get("direction_verdict", ""), b.get("direction_verdict", "")
        same = "yes" if va == vb else "NO"
        if same == "NO":
            moved.append(f)
        print(f"  {f:<26}{fmt(num(a['median_delta'])):>10}"
              f"{fmt(num(b['median_delta'])):>10}"
              f"{a.get('n_at_least_medium','') + '/' + b.get('n_at_least_medium',''):>12}"
              f"{va:>14}{vb:>14}  {same}")
    print()
    if moved:
        print(f"  {len(moved)} verdict(s) changed: {', '.join(moved)}")
        print("  That is a finding, not a problem -- it means the restricted")
        print("  runs were carrying part of that result, and the write-up has")
        print("  to say which set the claim rests on.")
    else:
        print("  No RQ1 verdict changed. The restriction costs a sentence and")
        print("  nothing else.")
    print()

    qp = {r["feature"]: r for r in read_csv(P / "rq2_replication.csv")}
    qs = {r["feature"]: r for r in read_csv(S / "rq2_replication.csv")}
    print("C. RQ2 — did any ordering or verdict move?")
    print(f"  {'feature':<26}{'verdict P':>18}{'verdict S':>18}"
          f"{'pairs P/S':>12}  same?")
    print("  " + "-" * 78)
    moved2 = []
    for f in sorted(set(qp) & set(qs)):
        a, b = qp[f], qs[f]
        va, vb = a.get("verdict", ""), b.get("verdict", "")
        oa, ob = a.get("ordering_a", ""), b.get("ordering_a", "")
        same = "yes" if (va == vb and oa == ob) else "NO"
        if same == "NO":
            moved2.append(f)
        print(f"  {f:<26}{va:>18} {vb:>18} "
              f"{a.get('n_pairs_agreeing','') + '/' + b.get('n_pairs_agreeing',''):>10}"
              f"  {same}")
    print()
    if moved2:
        print(f"  {len(moved2)} RQ2 row(s) changed: {', '.join(moved2)}")
    else:
        print("  No RQ2 ordering or verdict changed.")
    print()

    print("D. WHAT TO WRITE")
    if not moved and not moved2:
        print("  Every verdict is identical across the two sets. Report the")
        print("  restriction, report that the sensitivity analysis reproduced")
        print("  every verdict, and carry on with the primary numbers.")
    else:
        print("  At least one verdict differs. Report both sets explicitly and")
        print("  say which the claims rest on. Do not pick the set that gives")
        print("  the nicer answer after seeing both -- the primary set was")
        print("  defined by the model-held-constant condition, before this")
        print("  comparison, and that is the one the claims rest on.")
    print("=" * 92)
    return 0


if __name__ == "__main__":
    sys.exit(main())
