#!/usr/bin/env python3
"""Restrict the PRIMARY analysis to runs that requested the intended model.

This is a scope rule, not a deletion. The runs it removes stay in the collected
corpus and stay in the sensitivity analysis; they are excluded only from the
controlled comparison, so that "model held constant" is true of the set the RQ1
claims rest on.

How the model is determined
---------------------------
Per run, by reading the model strings that run's own HTTP log requested. A run
is kept only if every model it requested is the intended one. Nothing depends on
a transcribed list of run numbers, so the rule re-derives itself and cannot
drift out of date.

Where it hooks in
-----------------
Stages 2, 4, 5 and 7 all enumerate runs from out/runs.csv, so removing a run
there removes it from all of them. Stage 3 does NOT need re-running: the shards
for removed runs stay on disk and are simply never read again.

Usage::

    python3 select_models.py --out out            # dry run, shows the effect
    python3 select_models.py --out out --write

After writing, re-run the stages that read runs.csv:

    agentnet http-parse --root $R --out out
    agentnet align --out out
    agentnet tasks --out out
    python3 apply_exclusions.py --out out --write
    python3 install_coding_sheet.py --coded data/coding_draft.csv \
        --target-tasks out/tasks.csv --write out/task_coding_sheet.csv
    agentnet taxonomy --out out
    agentnet features --out out --allowlist data/provider_allowlist.v2.json
    agentnet validate --out out
    agentnet analyze --out out

SNAPSHOT THE SENSITIVITY RESULTS FIRST. The outputs currently in out/ were
computed over the unrestricted set and ARE the sensitivity analysis; recomputing
them later would be wasted work. Copy the tables aside before running this with
--write.

Idempotent: running it twice is a no-op with a note.
"""

from __future__ import annotations

import argparse
import collections
import csv
import json
import re
import sys
from pathlib import Path

MODEL_RE = re.compile(r'"model"\s*:\s*"([^"]*)"')


def read_csv(path: Path):
    with open(path, newline="", encoding="utf-8") as fh:
        r = csv.DictReader(fh)
        return list(r.fieldnames or []), list(r)


def write_csv(path: Path, cols, rows) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
    tmp.replace(path)


def models_in(log_path: str) -> set:
    """Every distinct model string the run requested. Empty if unreadable."""
    try:
        with open(log_path, encoding="utf-8", errors="replace") as fh:
            return {m.group(1) for m in MODEL_RE.finditer(fh.read())}
    except OSError:
        return set()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Restrict the primary analysis to the intended model.")
    ap.add_argument("--out", default="out")
    ap.add_argument("--rule", default="data/model_scope.v1.json")
    ap.add_argument("--write", action="store_true")
    args = ap.parse_args(argv)

    out = Path(args.out)
    runs_path = out / "runs.csv"
    dropped_path = out / "runs_excluded_models.csv"
    rule_path = Path(args.rule)

    for p in (runs_path, rule_path):
        if not p.is_file():
            print(f"not found: {p}", file=sys.stderr)
            return 2

    rule = json.loads(rule_path.read_text(encoding="utf-8"))
    intended = rule.get("intended_model")
    if not intended:
        print("the rule names no intended_model", file=sys.stderr)
        return 2

    cols, rows = read_csv(runs_path)
    if "http_log_path" not in cols:
        print(f"{runs_path} has no http_log_path column", file=sys.stderr)
        return 2

    print("=" * 76)
    print("MODEL SCOPE  (primary analysis set)")
    print("=" * 76)
    print(f"  rule      {rule_path}  (version {rule.get('version')}, "
          f"decided {rule.get('decided')})")
    print(f"  intended  {intended}")
    print(f"  runs.csv  {runs_path}  ({len(rows)} runs)")
    print()
    print("  reading the model each run requested from its own HTTP log ...")

    keepers, droppers = [], []
    unreadable = 0
    by_model = collections.Counter()
    for r in rows:
        ms = models_in(r.get("http_log_path", ""))
        if not ms:
            unreadable += 1
            keepers.append(r)       # cannot establish a violation; keep
            continue
        key = ",".join(sorted(ms))
        by_model[key] += 1
        if ms == {intended}:
            keepers.append(r)
        else:
            d = dict(r)
            d["requested_models"] = key
            droppers.append(d)

    print(f"  read {len(rows) - unreadable} logs"
          + (f", {unreadable} unreadable (kept)" if unreadable else ""))
    print()

    print("  MODEL SETS OBSERVED")
    for key, n in by_model.most_common():
        mark = "  <- intended" if key == intended else ""
        print(f"    {n:>5}  {key}{mark}")
    print()

    if not droppers:
        print("  NOTHING TO DO. Every run requested the intended model.")
        print("  Running this twice is safe.")
        print("=" * 76)
        return 0

    print(f"  REMOVING {len(droppers)} runs from the PRIMARY set "
          "(retained in the corpus and in the sensitivity analysis)")
    per_cell = collections.Counter(
        (r.get("agent", ""), r.get("provider_dir", "")) for r in droppers)
    for (a, p), n in sorted(per_cell.items()):
        print(f"    {a}/{p}: {n}")
    exps = sorted((r.get("exp_dir", "") for r in droppers))
    print(f"    run range: {exps[0]} .. {exps[-1]}" if exps else "")
    print()

    before = collections.Counter(
        (r.get("agent", ""), r.get("provider_dir", "")) for r in rows)
    after = collections.Counter(
        (r.get("agent", ""), r.get("provider_dir", "")) for r in keepers)
    print("  PROVIDER BALANCE, BEFORE -> AFTER")
    agents = sorted({a for a, _ in before})
    pdirs = sorted({p for _, p in before})
    for a in agents:
        tb = sum(before[(a, p)] for p in pdirs)
        ta = sum(after[(a, p)] for p in pdirs)
        cells = "  ".join(f"{p} {before[(a,p)]}->{after[(a,p)]}" for p in pdirs)
        print(f"    {a:<10} {cells}   total {tb}->{ta}")
    if len(agents) == 2:
        sh = {}
        for a in agents:
            t = sum(after[(a, p)] for p in pdirs)
            if t:
                sh[a] = [after[(a, p)] / t for p in pdirs]
        if len(sh) == 2:
            (a1, s1), (a2, s2) = sorted(sh.items())
            worst = max(abs(x - y) for x, y in zip(s1, s2))
            print(f"    largest provider-share gap between agents after: "
                  f"{worst:.1%}")
    print()

    expect = rule.get("expected_excluded_runs")
    if expect is not None and len(droppers) != expect:
        print(f"  NOTE: the rule expects {expect} excluded runs and this found "
              f"{len(droppers)}.")
        print("  Not an error -- the rule re-derives from the logs rather than")
        print("  from a fixed list -- but worth understanding before writing.")
        print()

    if not args.write:
        print("  DRY RUN -- nothing changed. Add --write to apply.")
        print("=" * 76)
        return 0

    if dropped_path.exists():
        print(f"  REFUSING: {dropped_path} already exists, so this may already")
        print("  have been applied. Remove it first if you mean to redo this.")
        print("=" * 76)
        return 1

    write_csv(dropped_path, cols + ["requested_models"], droppers)
    write_csv(runs_path, cols, keepers)
    print(f"  WROTE {runs_path}                {len(keepers)} runs")
    print(f"  WROTE {dropped_path}  {len(droppers)} runs, with the model each "
          "requested")
    print()
    print("  NOW RE-RUN, in this order. Stage 3 is NOT repeated.")
    print()
    print(f"    agentnet http-parse --root $R --out {out}")
    print(f"    agentnet align --out {out}")
    print(f"    agentnet tasks --out {out}")
    print(f"    python3 apply_exclusions.py --out {out} --write")
    print(f"    python3 install_coding_sheet.py --coded data/coding_draft.csv \\")
    print(f"        --target-tasks {out}/tasks.csv "
          f"--write {out}/task_coding_sheet.csv")
    print(f"    agentnet taxonomy --out {out}")
    print(f"    agentnet features --out {out} "
          "--allowlist data/provider_allowlist.v2.json")
    print(f"    agentnet validate --out {out}")
    print(f"    agentnet analyze --out {out}")
    print()
    print("  `agentnet tasks` rewrites a BLANK coding sheet, which is why the")
    print("  re-install step is not optional.")
    print("=" * 76)
    return 0


if __name__ == "__main__":
    sys.exit(main())
