# Task coding rubric

Twenty prompts, coded from the **instruction text only**. Never from a run,
a log, an outcome, or anything observed on the wire. If you find yourself
opening `out/` to decide a value, stop: that value is not admissible.

Code blind to results, and ideally twice — by two people, or by you a week
apart — recording agreement per factor in `task_properties.csv`.

## Headline taxonomy (proposed, retained)

Exactly one class per task. Assigned from the instruction, not from behaviour.

| Class | Assign when the instruction... |
|---|---|
| `web_only` | requires retrieving external content and requires no local execution |
| `local_execution` | requires running or writing something locally and requires no retrieval |
| `web_then_local` | requires both, with the local part consuming what was retrieved |

If a task requires both but the local part does **not** consume the retrieved
material, record it and raise it — it is neither `web_then_local` nor cleanly
either of the others, and the taxonomy may need a fourth class.

## Capability factors (descriptive metadata, underneath the taxonomy)

| Factor | Type | Code 1 / the value when the instruction... |
|---|---|---|
| `requires_web_fetch` | bool | names or implies retrieving external content |
| `requires_local_execution` | bool | requires running something locally |
| `requires_artefact_creation` | bool | necessarily requires a written executable or content artefact — see below |
| `has_retrieval_dependency` | bool | **retrieved** information determines a later action's *target* or *branch* — see below |
| `requires_iteration` | bool | implies repeat-until, check-and-retry, or "keep going until" |
| `n_required_fetches` | ordinal | count of distinct sources the instruction demands (not the number actually fetched) |
| `has_grounding_instruction` | bool | tells the agent to verify or cite against a source |
| `n_explicit_steps` | int | count of enumerated steps in the prompt (0 if unenumerated) |
| `named_domains_count` | int | count of **distinct** literal hostnames in the prompt (`github.com` twice is 1, not 2) |

`named_domains_count` is recorded for the audit and is **never** a feature: a
hostname list drawn from task text is structural leakage of the task label.

### `has_retrieval_dependency` — the narrow reading, and why

Code 1 **only** when information the agent had to retrieve determines what it
does next — specifically the *target* of a later action, or which *branch* it
takes. Code 0 when a later step merely consumes what was fetched.

| | |
|---|---|
| **1** | "Find the top 3 trending repos, then fetch each one's README" — *which* READMEs is decided by the first fetch |
| **1** | "If the issue count is > 50 fetch the issues page, otherwise fetch contributors" — the branch is decided by retrieved data |
| **1** | "Find the exact version on PyPI, then fetch `…/releases/tag/<version>`" — the second URL is built from the first result |
| **0** | "Fetch python.org, nodejs.org and rust-lang.org, then write a table" — three fetches, but all three addresses were known before starting |
| **0** | "Research X from two sources, then write a comparison" — the write-up consumes the research; nothing is *steered* by it |

The earlier, broader wording ("a later step consuming an earlier step's
output") made this column fire for eight of the twenty tasks, almost all of
them `web_then_local` — which made it a relabelling of the headline class
rather than independent evidence. The narrow reading leaves three tasks, and
those three do not track the class.

**Local retry loops are excluded.** "Run the tests and fix failures until they
pass" is control flow depending on an earlier action, but that earlier action
is local execution, not retrieval. It belongs to `requires_iteration`, which
exists for exactly that. Coding it here too would give two columns saying the
same thing.

### `requires_artefact_creation`

Code 1 when the instruction cannot be satisfied without producing a written
executable or content artefact — a script, a data file, a table saved to
disk. **An explicit filename or save command is not required.** "Write and run
a small script" produces an artefact whether or not the prompt names the file;
"implement a class and write four test cases" does too. Code 0 when the task
is satisfied by running something and reporting, with nothing left behind:
`python --version`, a one-line shell command typed at a prompt, listing a
directory.

This is separate from `requires_local_execution` on purpose. Both are local
demands, but "run `node --version` and tell me" and "build a CLI tool with
JSON persistence and three unit tests" are not the same amount of work, and
without this column the coding cannot tell them apart.

## Complexity — a count of operational demands

Complexity is **not** a separate coded column. It is derived from six of the
factors above, each a distinct kind of work the instruction demands:

| Side | Component | From |
|---|---|---|
| retrieval | `c_remote_retrieval` | `requires_web_fetch` |
| retrieval | `c_multiple_required_retrievals` | `n_required_fetches >= 2` |
| retrieval | `c_retrieval_dependency` | `has_retrieval_dependency` |
| local | `c_local_execution` | `requires_local_execution` |
| local | `c_artefact_creation` | `requires_artefact_creation` |
| local | `c_iterative_repair` | `requires_iteration` |

`complexity_score` is their sum, 0–6. **Three components a side, deliberately.**
A retrieval-weighted scale would make local tasks look artificially simple,
which is why `n_required_fetches` alone was rejected as a proxy. Nesting is
symmetric: multiple retrievals implies retrieval, an artefact implies local
execution — neither side gets finer resolution than the other.

`c_multiple_required_retrievals` means simply **two or more remote retrievals
are required**. It is not "independent" retrievals: a task with a retrieval
dependency still counts here, and whether the retrievals depend on one another
is what `c_retrieval_dependency` records separately.

**Two factors are excluded, and why:**

- `has_grounding_instruction` — "do not answer until you've fetched the page"
  is strictness of wording. It constrains how the agent should behave; it
  demands no additional operation.
- `named_domains_count` — naming a host makes a task *more* specific, if
  anything easier: the target is given rather than found. It measures domain
  specificity, and it is audit-only because it leaks the task label.

The score is a count of demands. It is **not** a difficulty rating and **not**
a runtime prediction, and nothing about it may come from a run.

## Prohibited inputs to every value above

Runtime. Packet or byte counts. Observed tool calls. Model turns.
Success or failure. Number of pages actually fetched. Any run-level table.

Complexity is a property of the instruction. If it can only be known after the
run, it is an outcome, and it belongs in the results, not in the coding.

## Before any factor is argued to be primary

Stage 6 must first emit:

- `task_factor_matrix.csv` — all 20 tasks × every factor, plus the headline
  class, printed verbatim in the report.
- `factor_contrast_support.csv` — for each proposed contrast: independent
  tasks on each side, the cross-tab against the headline class, and whether
  the contrast is separable from the taxonomy or merely a relabelling of it.

A contrast that reproduces the class split carries no independent evidence.
