#!/usr/bin/env python3
"""Carry the coded taxonomy across to a second corpus, keyed on the prompt.

The trap this exists to close
-----------------------------
``task_id`` is assigned per corpus, in sha order among whatever prompts that
corpus happens to contain. It is NOT a stable identifier across corpora. The
coding sheet, though, is keyed on ``task_id``, and Stage 6's validation checks
that every id in the sheet exists in tasks.csv -- which it will, since both
corpora number 0..19.

So copying a coded corpus-1 sheet into corpus 2's out directory passes
validation and assigns the wrong taxonomy_class to the wrong prompt, silently.
Every RQ2 result downstream would then be scrambled with no error raised
anywhere. That is a bad enough failure mode to be worth a script.

What this does
--------------
Joins the coded sheet to the second corpus on ``task_sha256`` -- the SHA-256 of
the whitespace-normalised prompt text, which is stable across corpora by
construction -- and writes a corpus-2 sheet carrying corpus-2 ids with the
original codes and the original coder's name.

A prompt in corpus 2 that was never coded is written out BLANK, so Stage 6
refuses to run until a human codes it. That is the correct outcome: an uncoded
prompt is uncoded, and silently inheriting a neighbouring prompt's class is
exactly what this script exists to prevent.

Re-using the codes rather than re-coding is the better choice for validity as
well as effort: the same prompt gets the same class, so an RQ2 difference
between corpora cannot be an artefact of the coder reading the rubric
differently the second time.

Usage::

    python3 rekey_coding_sheet.py \
        --coded out/task_coding_sheet.csv \
        --target-tasks out2/tasks.csv \
        --write out2/task_coding_sheet.csv

Omit ``--write`` for a dry run, which is the default.
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

COLUMNS = ["task_id", "task_sha256", "task_text", "taxonomy_class",
           "requires_web_fetch", "requires_local_execution",
           "requires_artefact_creation", "has_retrieval_dependency",
           "requires_iteration", "n_required_fetches",
           "has_grounding_instruction", "n_explicit_steps",
           "named_domains_count", "coder", "notes"]

CODED_FIELDS = COLUMNS[3:]          # taxonomy_class .. notes
FACTORS = COLUMNS[4:13]
CLASSES = ("web_only", "local_execution", "web_then_local")


def read_csv(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def is_coded(row: dict) -> bool:
    cls = (row.get("taxonomy_class") or "").strip()
    if cls not in CLASSES:
        return False
    return all((row.get(f) or "").strip() != "" for f in FACTORS)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Re-key a coded task_coding_sheet.csv onto another corpus's "
                    "task ids by joining on task_sha256.")
    ap.add_argument("--coded", required=True,
                    help="the CODED sheet, normally out/task_coding_sheet.csv")
    ap.add_argument("--target-tasks", required=True,
                    help="the second corpus's tasks.csv (from `agentnet tasks`)")
    ap.add_argument("--write", default=None,
                    help="where to write the re-keyed sheet; dry run if omitted")
    args = ap.parse_args(argv)

    coded_path, tasks_path = Path(args.coded), Path(args.target_tasks)
    for p in (coded_path, tasks_path):
        if not p.is_file():
            print(f"not found: {p}", file=sys.stderr)
            return 2

    coded = read_csv(coded_path)
    target = read_csv(tasks_path)

    by_sha = {}
    uncoded_source = []
    for r in coded:
        sha = (r.get("task_sha256") or "").strip()
        if not sha:
            continue
        if is_coded(r):
            by_sha[sha] = r
        else:
            uncoded_source.append(r)

    print("=" * 72)
    print("RE-KEY CODING SHEET ONTO A SECOND CORPUS")
    print("=" * 72)
    print(f"  coded sheet    {coded_path}   {len(coded)} rows, "
          f"{len(by_sha)} fully coded")
    print(f"  target corpus  {tasks_path}   {len(target)} prompts")
    print()

    out_rows = []
    matched = unmatched = 0
    for t in sorted(target, key=lambda r: int(r["task_id"])):
        sha = (t.get("task_sha256") or "").strip()
        row = {c: "" for c in COLUMNS}
        row["task_id"] = t["task_id"]
        row["task_sha256"] = sha
        row["task_text"] = t.get("task_text") or ""
        src = by_sha.get(sha)
        if src:
            for f in CODED_FIELDS:
                row[f] = (src.get(f) or "").strip()
            note = (row.get("notes") or "").strip()
            tag = (f"re-keyed from task_id {src.get('task_id')} of "
                   f"{coded_path.parent.name or coded_path.parent}")
            row["notes"] = f"{note}; {tag}" if note else tag
            matched += 1
        else:
            unmatched += 1
        out_rows.append(row)

    print("A. JOIN RESULT (on task_sha256, never on task_id)")
    print(f"   codes carried over       {matched:>3}")
    print(f"   left blank, need coding  {unmatched:>3}")
    print()

    id_moved = [(r["task_id"], by_sha[r["task_sha256"]]["task_id"])
                for r in out_rows
                if r["task_sha256"] in by_sha
                and str(r["task_id"]) != str(by_sha[r["task_sha256"]]["task_id"])]
    if id_moved:
        print(f"B. {len(id_moved)} PROMPTS CHANGED ID BETWEEN THE CORPORA")
        for new, old in id_moved[:12]:
            print(f"   corpus-1 id {old:>3}  ->  corpus-2 id {new:>3}")
        if len(id_moved) > 12:
            print(f"   ... and {len(id_moved) - 12} more")
        print("   Every one of these is a row a straight file copy would have")
        print("   mis-assigned, with no error raised.")
    else:
        print("B. NO PROMPT CHANGED ID BETWEEN THE CORPORA")
        print("   A straight copy would have happened to work here. It is still")
        print("   not safe to rely on: the ids coincide only because the same")
        print("   prompts sort the same way, which nothing guarantees.")
    print()

    if unmatched:
        print("C. PROMPTS IN CORPUS 2 WITH NO CODING")
        for r in out_rows:
            if not (r.get("taxonomy_class") or "").strip():
                print(f"   id {r['task_id']:>3}  {r['task_sha256'][:12]}  "
                      f"{r['task_text'][:58]!r}")
        print("   Written blank on purpose. Stage 6 will refuse to run until")
        print("   these are coded against data/task_coding_rubric.md -- the same")
        print("   rubric, so the codes stay comparable.")
        print()

    if uncoded_source:
        n = len(uncoded_source)
        print(f"D. {n} {'ROW' if n == 1 else 'ROWS'} IN THE SOURCE SHEET "
              f"{'IS' if n == 1 else 'ARE'} NOT FULLY CODED")
        print("   Skipped rather than partly carried over. A row with a class")
        print("   but a blank factor would fail Stage 6 anyway, and carrying")
        print("   half of it across hides which half is missing.")
        for r in uncoded_source[:8]:
            print(f"   source id {r.get('task_id')}  "
                  f"class={(r.get('taxonomy_class') or '')!r}")
        print()

    if args.write:
        dest = Path(args.write)
        if dest.exists():
            # Stage 5 emits a BLANK sheet at this path, so the file normally
            # exists already and replacing it is the whole point. A sheet with
            # any coded row is hand-entered work and is never overwritten.
            try:
                existing = read_csv(dest)
            except (OSError, UnicodeDecodeError) as exc:
                print(f"REFUSING TO OVERWRITE {dest}: cannot read it ({exc})")
                return 2
            coded_rows = [r for r in existing
                          if (r.get("taxonomy_class") or "").strip()
                          or any((r.get(f) or "").strip() for f in FACTORS)]
            if coded_rows:
                print(f"REFUSING TO OVERWRITE {dest}")
                print(f"  {len(coded_rows)} of its {len(existing)} rows already "
                      "carry coding. That is hand-entered")
                print("  work, and this script will not overwrite it. Write to a")
                print("  new path and merge by hand, or move the existing file")
                print("  aside if you are sure you want it replaced.")
                return 2
            print(f"  replacing the blank sheet Stage 5 wrote at {dest.name} "
                  "(no row in it carries coding)")
        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(dest, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=COLUMNS, lineterminator="\n")
            w.writeheader()
            w.writerows(out_rows)
        print(f"WROTE {dest}  ({len(out_rows)} rows, {matched} coded, "
              f"{unmatched} blank)")
        if unmatched:
            print("  Code the blank rows before running `agentnet taxonomy`.")
    else:
        print("DRY RUN -- nothing written. Add --write <path> to write the sheet.")

    print("=" * 72)
    return 0 if not unmatched else 1


if __name__ == "__main__":
    sys.exit(main())
