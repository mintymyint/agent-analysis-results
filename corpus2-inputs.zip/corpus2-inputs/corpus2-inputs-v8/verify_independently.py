#!/usr/bin/env python3
"""Independent verification of the Stage 9 outputs. Standard library only.

THIS SCRIPT DELIBERATELY IMPORTS NOTHING FROM agentnet. If it shared code with
the thing it checks, it would agree with a bug as readily as with a correct
answer. Every quantity below is recomputed from the stage outputs using the
plainest possible implementation:

  * Cliff's delta by the DOUBLE LOOP over every pair -- the definition, not
    the O(n log n) rank identity the pipeline uses for speed. Slow and
    obviously right.
  * medians by sorting and taking the middle.
  * the across-prompt summary by sorting twenty numbers.

It then compares against rq1_deltas.csv, rq1_summary.csv and
temporal_drift.csv and reports EVERY disagreement larger than the documented
output precision (6 significant digits, agentnet.io.writers.FLOAT_SIG_DIGITS).

It is a checker, not a stage. It writes no analysis output and changes
nothing. The one file it does write is a blank template for manual PCAP
inspection -- see section D.

    python3 verify_independently.py --out /Volumes/MINT/agentnet-out

Exit status is 1 if any check fails, so it can be run unattended.
"""

from __future__ import annotations

import argparse
import collections
import csv
import math
import os
import random
import sys

# --------------------------------------------------------------------------
# Tolerance
# --------------------------------------------------------------------------
# The pipeline writes floats at 6 significant digits. Two values agree if they
# match to that precision -- no looser. A disagreement at the 5th significant
# digit is a real disagreement and is reported.
SIG = 6


def agrees(a, b) -> bool:
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    if a == b:
        return True
    scale = max(abs(a), abs(b))
    if scale == 0:
        return True
    return abs(a - b) <= scale * (10.0 ** -(SIG - 1))


def fnum(v):
    if v is None or v == "":
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return None if (math.isnan(f) or math.isinf(f)) else f


# --------------------------------------------------------------------------
# The statistics, written out the slow obvious way
# --------------------------------------------------------------------------


def median(xs):
    """Sort, take the middle. No library call."""
    ys = sorted(xs)
    n = len(ys)
    if n == 0:
        return None
    if n % 2:
        return float(ys[n // 2])
    return (ys[n // 2 - 1] + ys[n // 2]) / 2.0


def cliffs_delta_bruteforce(xs, ys):
    """(#(x>y) - #(x<y)) / (n_x * n_y), by comparing every pair.

    This is O(n*m) and that is the point: it is the definition with no
    rearrangement, so it cannot share an error with the pipeline's rank form.
    """
    if not xs or not ys:
        return None
    gt = lt = 0
    for x in xs:
        for y in ys:
            if x > y:
                gt += 1
            elif x < y:
                lt += 1
    return (gt - lt) / float(len(xs) * len(ys))


# --------------------------------------------------------------------------
# Loading -- again, no shared code with the pipeline
# --------------------------------------------------------------------------


def read(path):
    if not os.path.exists(path):
        return None
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def build_frame(out):
    """run_id -> (agent, task_id), and the feature values per run."""
    feats = read(os.path.join(out, "run_features.csv"))
    rtasks = read(os.path.join(out, "run_tasks.csv"))
    tasks = read(os.path.join(out, "tasks.csv"))
    missing = [n for n, v in (("run_features.csv", feats),
                              ("run_tasks.csv", rtasks),
                              ("tasks.csv", tasks)) if v is None]
    if missing:
        sys.exit(f"missing input(s) in {out}: {', '.join(missing)}")

    sha_to_task, shared = {}, set()
    for t in tasks:
        tid = (t.get("task_id") or "").strip()
        sha_to_task[t.get("task_sha256", "")] = tid
        if (t.get("present_in_all_agents") or "").strip().lower() in (
                "1", "true", "yes"):
            shared.add(tid)

    run_task = {}
    for r in rtasks:
        if (r.get("parse_status") or "") != "ok":
            continue
        tid = sha_to_task.get(r.get("task_sha256", ""))
        # `is not None`, not truthiness: task_id "0" is a real task.
        if tid is not None and tid in shared:
            run_task[r["run_id"]] = tid

    cells = collections.defaultdict(list)     # (feature, agent, task) -> values
    runs = {}                                 # run_id -> (agent, task)
    for row in feats:
        rid = row.get("run_id", "")
        tid = run_task.get(rid)
        if tid is None:
            continue
        agent = row.get("agent", "")
        runs[rid] = (agent, tid)
        for k, v in row.items():
            if k in ("run_id", "agent"):
                continue
            f = fnum(v)
            if f is not None:
                cells[(k, agent, tid)].append(f)
    return cells, runs, sorted(shared, key=lambda t: (len(t), t))


# --------------------------------------------------------------------------
# A -- RQ1: per-cell medians, per-prompt deltas, across-prompt summary
# --------------------------------------------------------------------------

#: Checked at minimum. Three that carry a claim, one that is reported with a
#: caveat, and one that FAILED -- a verifier that only looks at the results
#: you like is not a verifier.
DEFAULT_FEATURES = [
    "bytes_ratio_down_up",
    "new_flows_per_active_min",
    "median_flow_duration_s",
    "bytes_down_total",
    "n_flows_tcp",
]


def absent_from(rows, feature, key="feature"):
    """True when a feature has NO rows at all in an output table.

    Kept distinct from a numerical disagreement on purpose. A feature missing
    entirely usually means it was demoted -- a design decision, not an error.
    But it can equally mean a feature silently stopped being computed, which
    would be serious, so absence is never skipped quietly: it is reported in
    its own section and has to be acknowledged with --expect-absent.
    """
    return not any(r.get(key) == feature for r in rows)


def verify_rq1(out, cells, task_ids, features, problems, notes, absences):
    deltas = read(os.path.join(out, "rq1_deltas.csv"))
    summary = read(os.path.join(out, "rq1_summary.csv"))
    cellcsv = read(os.path.join(out, "rq1_cells.csv"))
    if deltas is None or summary is None:
        problems.append("A: rq1_deltas.csv or rq1_summary.csv missing")
        return

    agents = sorted({a for (_, a, _) in cells})
    if len(agents) != 2:
        problems.append(f"A: expected two agents, found {agents}")
        return
    a, b = agents
    notes.append(f"A: delta orientation taken as {a} vs {b} "
                 f"(negative = {b} higher)")

    by_delta = {(r["feature"], r["task_id"]): r for r in deltas}
    by_cell = {}
    for r in (cellcsv or []):
        by_cell[(r["feature"], r["agent"], r["task_id"])] = r
    by_sum = {r["feature"]: r for r in summary}

    n_checked = n_cells = 0
    for feat in features:
        if absent_from(deltas, feat) and absent_from(summary, feat):
            absences.append((feat, "rq1_deltas.csv and rq1_summary.csv"))
            continue
        mine = []
        for tid in task_ids:
            xs = cells.get((feat, a, tid), [])
            ys = cells.get((feat, b, tid), [])
            if not xs or not ys:
                continue

            # -- the per-cell medians ------------------------------------
            for agent, vals in ((a, xs), (b, ys)):
                row = by_cell.get((feat, agent, tid))
                if row is None:
                    continue
                n_cells += 1
                mine_med = median(vals)
                theirs = fnum(row.get("median"))
                if not agrees(mine_med, theirs):
                    problems.append(
                        f"A: {feat} {agent} prompt {tid}: cell median "
                        f"{mine_med!r} vs rq1_cells.csv {theirs!r}")
                if int(row.get("n") or 0) != len(vals):
                    problems.append(
                        f"A: {feat} {agent} prompt {tid}: n={len(vals)} vs "
                        f"rq1_cells.csv {row.get('n')}")

            # -- the per-prompt delta, by brute force ---------------------
            d = cliffs_delta_bruteforce(xs, ys)
            mine.append(d)
            n_checked += 1
            row = by_delta.get((feat, tid))
            if row is None:
                problems.append(f"A: {feat} prompt {tid}: no row in "
                                f"rq1_deltas.csv")
                continue
            if not agrees(d, fnum(row.get("delta"))):
                problems.append(
                    f"A: {feat} prompt {tid}: brute-force delta {d!r} vs "
                    f"rq1_deltas.csv {row.get('delta')!r}")
            if row.get("agent_a") != a or row.get("agent_b") != b:
                problems.append(
                    f"A: {feat} prompt {tid}: orientation is "
                    f"{row.get('agent_a')}/{row.get('agent_b')}, expected "
                    f"{a}/{b} -- the SIGN of every delta depends on this")
            if int(row.get("n_a") or 0) != len(xs) or \
                    int(row.get("n_b") or 0) != len(ys):
                problems.append(
                    f"A: {feat} prompt {tid}: run counts {len(xs)}/{len(ys)} "
                    f"vs {row.get('n_a')}/{row.get('n_b')}")

        # -- the across-prompt summary -----------------------------------
        srow = by_sum.get(feat)
        if srow is None:
            problems.append(f"A: {feat}: no row in rq1_summary.csv")
            continue
        got = [d for d in mine if d is not None]
        if not agrees(median(got), fnum(srow.get("median_delta"))):
            problems.append(
                f"A: {feat}: across-prompt median delta {median(got)!r} vs "
                f"rq1_summary.csv {srow.get('median_delta')!r}")
        for name, want in (("n_positive", sum(1 for d in got if d > 0)),
                           ("n_negative", sum(1 for d in got if d < 0)),
                           ("n_zero", sum(1 for d in got if d == 0)),
                           ("n_tasks", len(got))):
            if int(srow.get(name) or 0) != want:
                problems.append(
                    f"A: {feat}: {name} recomputed {want} vs "
                    f"rq1_summary.csv {srow.get(name)}")
        # The scale columns, which is how a rank delta stops being misread.
        for col, agent in (("agent_a_median", a), ("agent_b_median", b)):
            if col not in srow:
                continue
            per_task = [median(cells.get((feat, agent, t), []))
                        for t in task_ids]
            per_task = [v for v in per_task if v is not None]
            if not agrees(median(per_task), fnum(srow.get(col))):
                problems.append(
                    f"A: {feat}: {col} recomputed {median(per_task)!r} vs "
                    f"rq1_summary.csv {srow.get(col)!r}")

    notes.append(f"A: recomputed {n_checked} per-prompt deltas by brute force "
                 f"and {n_cells} cell medians across {len(features)} features")


# --------------------------------------------------------------------------
# B -- temporal drift, recomputed from the run-level data
# --------------------------------------------------------------------------


def verify_drift(out, cells, runs, features, problems, notes, absences):
    """Recompute drift from run_features + runs.csv, independently.

    This matters more than it looks: drift decides whether an RQ1 feature may
    carry a claim at all, and it was the newest code in the pipeline.
    """
    drift = read(os.path.join(out, "temporal_drift.csv"))
    if drift is None:
        notes.append("B: temporal_drift.csv absent -- skipped")
        return
    runs_csv = read(os.path.join(out, "runs.csv"))
    if runs_csv is None:
        notes.append("B: runs.csv absent -- drift cannot be recomputed, and "
                     "the pipeline should be reporting it as NOT COMPUTED")
        return

    order = {}
    for r in runs_csv:
        try:
            k = int((r.get("exp_sort_key") or "").strip())
        except ValueError:
            continue
        if k >= 0:
            order[r.get("run_id", "")] = k

    feats = read(os.path.join(out, "run_features.csv"))
    values = {}
    for row in feats:
        rid = row.get("run_id", "")
        if rid in runs:
            values[rid] = row

    by_cell = collections.defaultdict(list)
    for rid, (agent, tid) in runs.items():
        if rid in order:
            by_cell[(agent, tid)].append(rid)

    theirs = {(r["feature"], r["agent"], r["task_id"]): r for r in drift}
    n = 0
    for feat in features:
        if absent_from(drift, feat):
            absences.append((feat, "temporal_drift.csv"))
            continue
        for (agent, tid), rids in sorted(by_cell.items()):
            rids = sorted(rids, key=lambda r: (order[r], r))
            cut = max(1, len(rids) // 3)
            first, last = rids[:cut], rids[-cut:]
            xs = [fnum(values[r].get(feat)) for r in last]
            ys = [fnum(values[r].get(feat)) for r in first]
            xs = [v for v in xs if v is not None]
            ys = [v for v in ys if v is not None]
            if len(xs) < 2 or len(ys) < 2:
                continue
            d = cliffs_delta_bruteforce(xs, ys)      # LAST vs FIRST
            row = theirs.get((feat, agent, tid))
            if row is None:
                problems.append(f"B: {feat} {agent} prompt {tid}: no row in "
                                f"temporal_drift.csv")
                continue
            n += 1
            if not agrees(d, fnum(row.get("delta"))):
                problems.append(
                    f"B: {feat} {agent} prompt {tid}: brute-force drift "
                    f"{d!r} vs temporal_drift.csv {row.get('delta')!r}")
            if int(row.get("n_first") or 0) != len(ys) or \
                    int(row.get("n_last") or 0) != len(xs):
                problems.append(
                    f"B: {feat} {agent} prompt {tid}: thirds {len(ys)}/"
                    f"{len(xs)} vs {row.get('n_first')}/{row.get('n_last')}")
    notes.append(f"B: recomputed {n} drift deltas by brute force from the "
                 f"run-level data")


# --------------------------------------------------------------------------
# C -- the per-agent drift split (reporting only; no new control)
# --------------------------------------------------------------------------


def split_drift_by_agent(out, problems, notes):
    """Split the EXISTING drift cells by agent and print both sides.

    Not a new control. temporal_drift.csv already holds one row per feature x
    agent x prompt; the summary aggregated both agents into one median, and
    collection was OpenClaw -> Hermes -> OpenClaw, so 'latest third' means a
    different period for each. This just reports the two halves separately.
    """
    drift = read(os.path.join(out, "temporal_drift.csv"))
    summary = read(os.path.join(out, "rq1_summary.csv"))
    if drift is None or summary is None:
        notes.append("C: drift or summary missing -- skipped")
        return []
    plat = {r["feature"]: fnum(r.get("median_delta")) for r in summary}
    verdicts = {r["feature"]: r.get("direction_verdict", "") for r in summary}

    per = collections.defaultdict(list)
    for r in drift:
        if r.get("status") != "ok":
            continue
        d = fnum(r.get("delta"))
        if d is not None:
            per[(r["feature"], r["agent"])].append(d)

    agents = sorted({a for (_, a) in per})
    rows = []
    for feat in sorted({f for (f, _) in per}):
        row = {"feature": feat, "rq1_verdict": verdicts.get(feat, ""),
               "platform_delta": plat.get(feat)}
        for ag in agents:
            vals = per.get((feat, ag), [])
            row[f"drift_signed_{ag}"] = median(vals)
            row[f"drift_abs_{ag}"] = median([abs(v) for v in vals])
            row[f"n_cells_{ag}"] = len(vals)
        rows.append(row)

    print()
    print("=" * 78)
    print("C. DRIFT SPLIT BY AGENT  (reporting only -- no new control)")
    print("=" * 78)
    print("  Collection ran OpenClaw -> Hermes -> OpenClaw, so the nested")
    print("  agent's 'latest third' is a DIFFERENT period from the other's.")
    print("  A signed drift is the median of (latest third vs earliest third)")
    print("  within one agent on one prompt: positive = later runs higher.")
    print()
    head = f"  {'feature':26s} {'verdict':12s} {'platform':>9s}"
    for ag in agents:
        head += f" {ag[:9] + ' signed':>17s} {'|abs|':>7s}"
    print(head)
    for r in rows:
        line = (f"  {r['feature']:26s} {r['rq1_verdict']:12s} "
                f"{_fmt(r['platform_delta']):>9s}")
        for ag in agents:
            line += (f" {_fmt(r[f'drift_signed_{ag}']):>17s}"
                     f" {_fmt(r[f'drift_abs_{ag}']):>7s}")
        print(line)
    print()
    print("  How to read it: if the two agents' SIGNED drifts point in")
    print("  OPPOSITE directions, a single monotone trend cannot explain the")
    print("  platform difference -- the aggregate flag was over-warning. If")
    print("  they point the SAME way and are comparable to the platform")
    print("  delta, the confound is live for that feature.")
    return rows


def _fmt(v, nd=3):
    return "n/a" if v is None else f"{v:.{nd}f}"


# --------------------------------------------------------------------------
# D -- the manual PCAP inspection template
# --------------------------------------------------------------------------

#: Prompts that behaved unusually in the results and are therefore worth a
#: human eye. 4, 6 and 11 flatten the byte-volume features; 13 is the weakest
#: point on two of the three claim-carrying features at once.
ODD_PROMPTS = ("4", "6", "11", "13")

#: What a person can actually check in Wireshark without heroics.
MANUAL_FEATURES = ("bytes_up_total", "bytes_down_total",
                   "bytes_ratio_down_up", "n_flows_tcp",
                   "median_flow_duration_s", "pktsize_up_median",
                   "pktsize_down_median")


def write_manual_template(out, cells, runs, seed, problems, notes):
    """Pick a stratified set of runs and pre-fill what the pipeline claims.

    The expected column is filled from run_features.csv so the person checking
    only has to write down what they SEE, plus a verdict. Nothing else about
    this file is generated: the observed column stays blank on purpose.
    """
    feats = read(os.path.join(out, "run_features.csv"))
    factors = read(os.path.join(out, "task_factor_matrix.csv"))
    if feats is None or factors is None:
        notes.append("D: run_features.csv or task_factor_matrix.csv missing "
                     "-- template not written")
        return None
    cls = {(r.get("task_id") or "").strip(): r.get("taxonomy_class", "")
           for r in factors}
    rows_by_run = {r["run_id"]: r for r in feats}

    # Stratify: every odd prompt in both agents, then fill up to ~10 captures
    # with one prompt per class per agent.
    agents = sorted({a for (a, _) in runs.values()})
    by_cell = collections.defaultdict(list)
    for rid, (agent, tid) in runs.items():
        by_cell[(agent, tid)].append(rid)

    rng = random.Random(seed)
    picked = []
    for tid in ODD_PROMPTS:
        for agent in agents:
            ids = sorted(by_cell.get((agent, tid), []))
            if ids:
                picked.append((agent, tid, rng.choice(ids), "odd prompt"))
    seen_classes = set()
    for agent in agents:
        for tid in sorted({t for (a, t) in by_cell if a == agent},
                          key=lambda t: (len(t), t)):
            c = cls.get(tid, "")
            if tid in ODD_PROMPTS or (agent, c) in seen_classes or not c:
                continue
            ids = sorted(by_cell.get((agent, tid), []))
            if ids:
                picked.append((agent, tid, rng.choice(ids), "class cover: " + c))
                seen_classes.add((agent, c))

    out_rows = []
    for agent, tid, rid, why in picked:
        src = rows_by_run.get(rid, {})
        for feat in MANUAL_FEATURES:
            out_rows.append({
                "run_id": rid, "agent": agent, "task_id": tid,
                "taxonomy_class": cls.get(tid, ""), "selected_because": why,
                "feature": feat,
                "expected_value": src.get(feat, ""),
                "observed_value": "",
                "verdict": "",
                "notes": "",
            })
        out_rows.append({
            "run_id": rid, "agent": agent, "task_id": tid,
            "taxonomy_class": cls.get(tid, ""), "selected_because": why,
            "feature": "flow_termination_cause",
            "expected_value": "",
            "observed_value": "",
            "verdict": "",
            "notes": "FIN-client | FIN-server | RST | capture-end | idle-then-FIN",
        })

    path = os.path.join(out, "manual_validation.csv")
    cols = ["run_id", "agent", "task_id", "taxonomy_class",
            "selected_because", "feature", "expected_value",
            "observed_value", "verdict", "notes"]
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        for r in sorted(out_rows, key=lambda r: (r["agent"], int(r["task_id"])
                                                 if r["task_id"].isdigit()
                                                 else 0, r["feature"])):
            w.writerow(r)
    notes.append(f"D: wrote {path} -- {len({r['run_id'] for r in out_rows})} "
                 f"captures x {len(MANUAL_FEATURES) + 1} rows, expected values "
                 f"pre-filled, observed blank")
    return path


# --------------------------------------------------------------------------


def main(argv=None):
    p = argparse.ArgumentParser(
        description="Independently verify agentnet Stage 9 outputs. "
                    "Imports nothing from agentnet.")
    p.add_argument("--out", default=os.environ.get("AGENTNET_OUT", "out"))
    p.add_argument("--features", default=",".join(DEFAULT_FEATURES),
                   help="comma-separated; the default set includes one "
                        "feature that FAILED, deliberately")
    p.add_argument("--limit-prompts", type=int, default=None,
                   help="check only the first N prompts (the brute-force "
                        "delta is O(n*m); the full set takes a few minutes)")
    p.add_argument("--seed", type=int, default=20260914,
                   help="seed for picking which run to inspect per cell")
    p.add_argument("--expect-absent", dest="expect_absent", default="",
                   metavar="FEATURE[,FEATURE]",
                   help="features you KNOW are absent from the outputs, e.g. "
                        "because a plan revision demoted them. Naming one "
                        "turns its absence from a failure into a confirmed "
                        "expectation. Absence is never ignored silently: a "
                        "feature that vanished for a bad reason looks exactly "
                        "the same from here.")
    p.add_argument("--skip-template", action="store_true")
    args = p.parse_args(argv)

    out = args.out
    features = [f.strip() for f in args.features.split(",") if f.strip()]
    print(f"independent verification of {out}")
    print(f"  no agentnet code is imported; Cliff's delta is recomputed by "
          f"double loop")
    print(f"  tolerance: {SIG} significant digits, the documented output "
          f"precision")
    print()

    cells, runs, task_ids = build_frame(out)
    if args.limit_prompts:
        task_ids = task_ids[:args.limit_prompts]
    print(f"  frame: {len(runs)} runs, {len(task_ids)} shared prompts, "
          f"features checked: {', '.join(features)}")

    expect_absent = {f.strip() for f in args.expect_absent.split(",")
                     if f.strip()}
    problems, notes, absences = [], [], []
    verify_rq1(out, cells, task_ids, features, problems, notes, absences)
    verify_drift(out, cells, runs, features, problems, notes, absences)

    print()
    print("=" * 78)
    print("A + B. NUMERICAL VERIFICATION")
    print("=" * 78)
    for n in notes:
        print("  " + n)
    print()
    if problems:
        print(f"  {len(problems)} DISAGREEMENT(S):")
        for pr in problems:
            print("    - " + pr)
    else:
        print("  no disagreements at the documented precision")

    unexpected = []
    if absences:
        print()
        print("  FEATURES ABSENT FROM THE OUTPUTS (not a numerical "
              "disagreement):")
        seen = set()
        for feat, where in absences:
            if (feat, where) in seen:
                continue
            seen.add((feat, where))
            tag = "expected" if feat in expect_absent else "NOT EXPECTED"
            print(f"    - {feat}: no rows in {where}  [{tag}]")
            if feat not in expect_absent:
                unexpected.append(feat)
        if unexpected:
            print()
            print(f"    {len(set(unexpected))} feature(s) vanished without "
                  f"being declared. If a plan revision demoted them, re-run")
            print(f"    with --expect-absent "
                  f"{','.join(sorted(set(unexpected)))} and check the reason")
            print(f"    is recorded in data/analysis_plan_changelog.md. If "
                  f"not, a feature stopped being computed and that is a bug.")
        else:
            print()
            print("    all declared in advance; not counted as failures")

    split_drift_by_agent(out, problems, notes)

    if not args.skip_template:
        print()
        print("=" * 78)
        print("D. MANUAL PCAP TEMPLATE")
        print("=" * 78)
        tnotes = []
        write_manual_template(out, cells, runs, args.seed, problems, tnotes)
        for n in tnotes:
            print("  " + n)

    print()
    return 1 if (problems or unexpected) else 0


if __name__ == "__main__":
    sys.exit(main())
