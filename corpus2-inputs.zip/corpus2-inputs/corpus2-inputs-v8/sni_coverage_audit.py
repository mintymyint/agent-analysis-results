#!/usr/bin/env python3
"""Is the allowlist complete for this corpus? A coverage check, not a source.

Why this exists
---------------
The provider split matches SNI hostnames EXACTLY, not by suffix. That is a
deliberate choice carried over from the original pipeline, and it has one
failure mode: a provider reached on a hostname the allowlist does not list is
classified as NON-PROVIDER, silently, with no error anywhere. Nothing in the
pipeline can notice, because to the code a missing host and a genuine
third-party host look identical. ``nonprovider_bytes_frac`` -- PRIMARY for RQ2
-- then reads near 1.0 and looks like a finding.

Corpus 2 makes that concrete. The frozen v1 allowlist holds two hosts,
``openrouter.ai`` and ``api.together.xyz``. Together AI's currently documented
base URL is ``api.together.ai``, and SiliconFlow's documentation publishes two
different hosts. Under exact matching, none of that is covered by v1.

What this is and is not
-----------------------
This lists the SNI hostnames the captures actually contain, with their byte
share, and marks each in or out of whichever allowlist you point it at. That
makes an incomplete allowlist visible.

It is NOT a way to build the allowlist. The standing instruction is that the
list is not derived from or expanded using the corpus, because then the
provider split becomes a function of the data it is used to describe. So when
a hostname shows up here that should have been provider traffic, the
correction comes from the base_url configured in the agent, and it is recorded
as a new numbered allowlist file -- not pasted from this output.

Usage (after Stage 3 has written shards for corpus 2)::

    python3 sni_coverage_audit.py --out out \
        --allowlist data/provider_allowlist.v2.json

Reads ``<out>/cache/pcap/*.json`` only. Writes nothing.
"""

from __future__ import annotations

import argparse
import collections
import json
import sys
from pathlib import Path


def load_allowlist(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    return {
        "exact": {str(h).strip().lower().rstrip(".") for h in (data.get("exact") or [])},
        "suffixes": tuple(data.get("suffixes") or []),
        "match": data.get("match", "exact_on_sni"),
        "version": data.get("version"),
        "path": str(path),
    }


def classify(sni, al: dict) -> str:
    """Byte-for-byte the rule in agentnet.features.build.Allowlist.classify."""
    if not sni:
        return "unclassifiable"
    host = str(sni).strip().lower().rstrip(".")
    if host in al["exact"]:
        return "provider"
    if al["suffixes"] and any(host.endswith(s) for s in al["suffixes"]):
        return "provider"
    return "nonprovider"


def scan(out: Path) -> dict:
    """Aggregate upstream TCP bytes per SNI across every shard.

    The flow filter is the same one provider_split uses -- proto tcp, upstream
    leg, bytes_up + bytes_down. Anything else would be auditing a different
    quantity than the feature it is meant to check.
    """
    shard_dir = out / "cache" / "pcap"
    if not shard_dir.is_dir():
        raise SystemExit(
            f"no shards at {shard_dir}\n"
            f"Run `agentnet pcap-extract --root <CORPUS2> --out {out}` first; "
            "this audit reads what that stage wrote, it does not open captures.")

    by_host = collections.Counter()
    flows_by_host = collections.Counter()
    runs_by_host = collections.defaultdict(set)
    # Shard names are <agent>__<provider_dir>__<exp>, so the provider directory
    # is recoverable without reading runs.csv. With two providers in one corpus
    # the pooled table cannot answer "did the silicon runs actually reach
    # SiliconFlow", which is the question worth asking.
    by_pdir = collections.defaultdict(collections.Counter)
    runs_per_pdir = collections.defaultdict(set)
    no_sni_bytes = 0
    no_sni_flows = 0
    n_shards = n_bad = 0

    for shard in sorted(shard_dir.glob("*.json")):
        n_shards += 1
        try:
            payload = json.loads(shard.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            n_bad += 1
            continue
        run_id = shard.stem.replace("__", "/")
        parts = shard.stem.split("__")
        pdir = parts[1] if len(parts) >= 3 else "(unknown)"
        runs_per_pdir[pdir].add(run_id)
        for f in payload.get("flows") or ():
            if f.get("proto") != "tcp" or f.get("capture_leg") != "upstream":
                continue
            b = (f.get("bytes_up") or 0) + (f.get("bytes_down") or 0)
            sni = f.get("sni")
            if not sni:
                no_sni_bytes += b
                no_sni_flows += 1
                continue
            host = str(sni).strip().lower().rstrip(".")
            by_host[host] += b
            flows_by_host[host] += 1
            runs_by_host[host].add(run_id)
            by_pdir[pdir][host] += b

    return {
        "n_shards": n_shards, "n_bad_shards": n_bad,
        "by_host": by_host, "flows_by_host": flows_by_host,
        "runs_by_host": {h: len(v) for h, v in runs_by_host.items()},
        "no_sni_bytes": no_sni_bytes, "no_sni_flows": no_sni_flows,
        "by_pdir": {p: c for p, c in by_pdir.items()},
        "runs_per_pdir": {p: len(v) for p, v in runs_per_pdir.items()},
    }


def _human(n: float) -> str:
    x = float(n)
    for unit in ("B", "kB", "MB", "GB", "TB"):
        if abs(x) < 1024 or unit == "TB":
            return f"{int(x)} B" if unit == "B" else f"{x:.1f} {unit}"
        x /= 1024
    return f"{x:.1f} TB"


def report_by_pdir(scanned: dict, al: dict) -> None:
    """Which hosts did each provider directory's runs actually reach?

    With two providers side by side in one corpus, the pooled table in section A
    cannot answer that: a host appearing in it says nothing about which runs
    reached it. A directory called 'silicon' is a label someone typed, and the
    captures are the only evidence of where the traffic went.
    """
    by_pdir = scanned.get("by_pdir") or {}
    if len(by_pdir) < 2:
        return
    print("A2. TOP HOSTS PER PROVIDER DIRECTORY")
    print("    The directory name is a label. This is the traffic.")
    print()
    for pdir in sorted(by_pdir):
        counts = by_pdir[pdir]
        tot = sum(counts.values())
        n_runs = scanned["runs_per_pdir"].get(pdir, 0)
        print(f"    {pdir}/   {n_runs} runs, {_human(tot)} with an SNI")
        for host, b in counts.most_common(5):
            mark = " IN " if classify(host, al) == "provider" else "out "
            print(f"      {mark}{host:<42}{b / tot if tot else 0:>7.1%}")
        extra = len(counts) - 5
        if extra > 0:
            print(f"      ... {extra} more host{'' if extra == 1 else 's'}")
        print()
    print("    What to check: the provider host at the top of each block should")
    print("    be the one that directory is named after. If the 'silicon' runs")
    print("    are dominated by a Together host, or the other way round, the")
    print("    directory labels and the traffic disagree -- and the labels are")
    print("    what you would have reported.")
    print()


def report(scanned: dict, al: dict, top: int) -> int:
    by_host = scanned["by_host"]
    print(f"ALLOWLIST: {al['path']}  (version {al['version']}, "
          f"match={al['match']}, {len(al['exact'])} exact, "
          f"{len(al['suffixes'])} suffix)")
    print(f"SHARDS READ: {scanned['n_shards']}"
          + (f"   ({scanned['n_bad_shards']} unreadable)"
             if scanned["n_bad_shards"] else ""))
    print()

    if not by_host and not scanned["no_sni_bytes"]:
        print("  no upstream TCP flows in any shard. Either extraction has not")
        print("  run or no flow was labelled 'upstream'; either way the provider")
        print("  split has nothing to work on.")
        return 2

    prov_bytes = sum(b for h, b in by_host.items()
                     if classify(h, al) == "provider")
    non_bytes = sum(b for h, b in by_host.items()
                    if classify(h, al) == "nonprovider")
    classifiable = prov_bytes + non_bytes
    total = classifiable + scanned["no_sni_bytes"]

    print("A. EVERY SNI HOSTNAME IN THE CORPUS, BY UPSTREAM TCP BYTES")
    print(f"   {'':<4}{'host':<40}{'bytes':>12}{'share':>9}{'flows':>8}{'runs':>7}")
    ranked = by_host.most_common()
    shown = ranked if top <= 0 else ranked[:top]
    for host, b in shown:
        cls = classify(host, al)
        mark = " IN " if cls == "provider" else "out "
        share = b / classifiable if classifiable else 0.0
        print(f"   {mark}{host:<40}{_human(b):>12}{share:>8.1%}"
              f"{scanned['flows_by_host'][host]:>8}"
              f"{scanned['runs_by_host'][host]:>7}")
    if top > 0 and len(ranked) > top:
        rest = sum(b for _, b in ranked[top:])
        extra = len(ranked) - top
        print(f"   ... {extra} more host{'' if extra == 1 else 's'}, "
              f"{_human(rest)} ({rest / classifiable:.1%}) between them")
    print()
    print("   'IN' = on the allowlist, counted as provider. 'out' = counted as")
    print("   NON-provider. Share is of SNI-classifiable bytes, matching how")
    print("   nonprovider_bytes_frac is defined.")
    print()

    report_by_pdir(scanned, al)

    print("B. WHAT THE SPLIT COMES TO")
    print(f"   provider bytes        {_human(prov_bytes):>12}")
    print(f"   non-provider bytes    {_human(non_bytes):>12}")
    print(f"   no SNI observed       {_human(scanned['no_sni_bytes']):>12}"
          f"   ({scanned['no_sni_flows']} flows, excluded from BOTH sides)")
    if classifiable:
        print(f"   nonprovider_bytes_frac  {non_bytes / classifiable:.4f}"
              "   (over classifiable bytes only)")
    if total:
        print(f"   classifiable_byte_frac  {classifiable / total:.4f}")
    print()

    print("C. ALLOWLIST ENTRIES THAT NEVER APPEARED")
    unseen = sorted(h for h in al["exact"] if h not in by_host)
    if unseen:
        for h in unseen:
            print(f"   {h}")
        print("   Harmless: an entry that matches nothing changes no number. It")
        print("   is listed so the file can be read against reality, not")
        print("   because it needs removing.")
    else:
        print("   none -- every listed host appears in the corpus")
    print()

    print("D. THE QUESTION THIS AUDIT EXISTS TO ANSWER")
    top_out = [(h, b) for h, b in ranked if classify(h, al) == "nonprovider"]
    if not top_out:
        print("   Every hostname present is on the allowlist, so no provider")
        print("   traffic can be sitting in the non-provider bucket.")
    else:
        print("   The hosts marked 'out' above are being counted as")
        print("   non-provider. Read the largest few and decide, from the")
        print("   base_url each agent was CONFIGURED with, whether any of them")
        print("   is in fact the model provider:")
        for h, b in top_out[:6]:
            share = b / classifiable if classifiable else 0.0
            print(f"      {h:<40}{share:>7.1%} of classifiable bytes")
        print()
        print("   If one of them is the provider, the allowlist is incomplete")
        print("   and nonprovider_bytes_frac is wrong for this corpus. The fix")
        print("   is a NEW numbered allowlist file carrying that host with its")
        print("   source recorded, leaving the existing files intact -- not an")
        print("   edit to a frozen file, and not a host copied out of this")
        print("   report because it looked plausible.")
    print()
    print("   This output is a coverage check on the allowlist. It is not a")
    print("   source for it. Deriving the list from the corpus would make the")
    print("   provider split a function of the data it describes.")
    return 0 if not top_out else 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Report the SNI hostnames a corpus contains and mark each "
                    "in or out of an allowlist. Reads shards only; writes nothing.")
    ap.add_argument("--out", default="out",
                    help="output directory holding cache/pcap shards")
    ap.add_argument("--allowlist", default="data/provider_allowlist.v2.json")
    ap.add_argument("--top", type=int, default=25,
                    help="hosts to list in full; 0 for all")
    args = ap.parse_args(argv)

    al_path = Path(args.allowlist)
    if not al_path.is_file():
        print(f"allowlist not found: {al_path}", file=sys.stderr)
        return 2

    print("=" * 72)
    print("SNI COVERAGE AUDIT")
    print("=" * 72)
    print()
    rc = report(scan(Path(args.out)), load_allowlist(al_path), args.top)
    print("=" * 72)
    print({0: "ALLOWLIST COVERS EVERY HOST PRESENT",
           1: "HOSTS ARE BEING COUNTED AS NON-PROVIDER -- CHECK SECTION D",
           2: "COULD NOT RUN"}[rc])
    print("=" * 72)
    return rc


if __name__ == "__main__":
    sys.exit(main())
