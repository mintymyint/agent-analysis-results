#!/usr/bin/env python3
"""Restrict the corpus to the intended provider directories.

Why here
--------
Stages 2, 4, 5 and 7 all enumerate runs from out/runs.csv, so removing a run
there removes it from every one of them. Stage 3 does not need re-running: the
shards for dropped runs stay on disk and are simply never read.

The rule and its grounds live in data/provider_scope.v1.json. Keyed on the
provider DIRECTORY the run was collected under -- not on the SNI hostnames its
capture turned out to contain, because filtering on observed hosts would make
the corpus definition a function of the captures it describes.

Usage::

    python3 select_providers.py --out out            # dry run, shows the effect
    python3 select_providers.py --out out --write

After writing, re-run the stages that read runs.csv so everything downstream
agrees:

    agentnet http-parse --root $R --out out
    agentnet align --out out
    agentnet tasks --out out

Idempotent: running it twice is a no-op with a note.
"""

from __future__ import annotations

import argparse
import collections
import csv
import json
import sys
from pathlib import Path


def read_csv(path: Path):
    with open(path, newline="", encoding="utf-8") as fh:
        r = csv.DictReader(fh)
        return list(r.fieldnames or []), list(r)


def write_csv(path: Path, cols, rows) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
    tmp.replace(path)


def table(rows, title):
    """Per agent x provider_dir counts."""
    c = collections.Counter((r.get("agent", ""), r.get("provider_dir", ""))
                            for r in rows)
    agents = sorted({a for a, _ in c})
    pdirs = sorted({p for _, p in c})
    width = max([len(p) for p in pdirs] + [8]) + 2
    print(f"  {title}")
    print("    " + " " * 12 + "".join(f"{p:>{width}}" for p in pdirs)
          + f"{'total':>9}")
    for a in agents:
        counts = [c[(a, p)] for p in pdirs]
        print(f"    {a:<12}" + "".join(f"{n:>{width}}" for n in counts)
              + f"{sum(counts):>9}")
    tot = [sum(c[(a, p)] for a in agents) for p in pdirs]
    print("    " + f"{'TOTAL':<12}" + "".join(f"{n:>{width}}" for n in tot)
          + f"{sum(tot):>9}")
    # share of each agent's runs by provider, which is what matters for RQ1
    if len(agents) == 2 and len(pdirs) > 1:
        print()
        shares = {}
        for a in agents:
            t = sum(c[(a, p)] for p in pdirs)
            if t:
                shares[a] = [c[(a, p)] / t for p in pdirs]
        if len(shares) == 2:
            (a1, s1), (a2, s2) = sorted(shares.items())
            print("    provider share within each agent")
            print("    " + " " * 12 + "".join(f"{p:>{width}}" for p in pdirs))
            for a, s in ((a1, s1), (a2, s2)):
                print(f"    {a:<12}" + "".join(f"{v:>{width}.1%}" for v in s))
            worst = max(abs(x - y) for x, y in zip(s1, s2))
            print(f"    largest gap between {a1} and {a2}: {worst:.1%}")
    print()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Keep only the provider directories named in the scope rule.")
    ap.add_argument("--out", default="out")
    ap.add_argument("--rule", default="data/provider_scope.v1.json")
    ap.add_argument("--write", action="store_true")
    args = ap.parse_args(argv)

    out = Path(args.out)
    runs_path = out / "runs.csv"
    dropped_path = out / "runs_excluded_providers.csv"
    rule_path = Path(args.rule)

    for p in (runs_path, rule_path):
        if not p.is_file():
            print(f"not found: {p}", file=sys.stderr)
            return 2

    rule = json.loads(rule_path.read_text(encoding="utf-8"))
    keep = set(rule.get("keep") or [])
    if not keep:
        print("the scope rule names no provider directories to keep",
              file=sys.stderr)
        return 2

    cols, rows = read_csv(runs_path)
    if "provider_dir" not in cols:
        print(f"{runs_path} has no provider_dir column", file=sys.stderr)
        return 2

    print("=" * 76)
    print("PROVIDER SCOPE")
    print("=" * 76)
    print(f"  rule      {rule_path}  (version {rule.get('version')}, "
          f"decided {rule.get('decided')})")
    print(f"  keep      {', '.join(sorted(keep))}")
    print(f"  runs.csv  {runs_path}  ({len(rows)} runs)")
    print()

    present = sorted({r.get("provider_dir", "") for r in rows})
    keepers = [r for r in rows if r.get("provider_dir", "") in keep]
    droppers = [r for r in rows if r.get("provider_dir", "") not in keep]

    table(rows, "BEFORE")
    if not droppers:
        print("  NOTHING TO DO.")
        print(f"  Every run is already under {', '.join(sorted(keep))}.")
        print("  Running this twice is safe.")
        print("=" * 76)
        return 0

    print(f"  DROPPING {len(droppers)} runs under: "
          f"{', '.join(sorted({r.get('provider_dir','') for r in droppers}))}")
    print()
    table(keepers, "AFTER")

    missing = keep - set(present)
    if missing:
        print(f"  WARNING: the rule keeps {', '.join(sorted(missing))}, which "
              "is not in runs.csv at all.")
        print("  Check --out points at the right corpus before writing.")
        print()

    if not keepers:
        print("  REFUSING: that would leave no runs at all.")
        print("=" * 76)
        return 1

    print("  WHAT TO READ IN THE 'AFTER' TABLE")
    print("  The provider share within each agent is the thing that matters.")
    print("  RQ1 compares the two agents and pools across providers, so if both")
    print("  carry the same mix, provider adds within-agent variance and")
    print("  nothing else. If the mix differs between them, provider varies")
    print("  together with agent and an RQ1 difference cannot be separated from")
    print("  a provider difference. No cutoff is applied here -- a threshold")
    print("  invented after seeing the corpus would not be worth anything.")
    print()

    if not args.write:
        print("  DRY RUN -- nothing changed. Add --write to apply.")
        print("=" * 76)
        return 0

    write_csv(dropped_path, cols, droppers)
    write_csv(runs_path, cols, keepers)
    print(f"  WROTE {runs_path}                  {len(keepers)} runs")
    print(f"  WROTE {dropped_path}  {len(droppers)} runs, kept for the record")
    print()
    print("  NOW RE-RUN THE STAGES THAT READ runs.csv, so the task set, the")
    print("  MITM parse and the alignment all agree with the new scope:")
    print()
    print("    agentnet http-parse --root $R --out " + str(out))
    print("    agentnet align --out " + str(out))
    print("    agentnet tasks --out " + str(out))
    print()
    print("  Stage 3 does NOT need re-running. The shards for the dropped runs")
    print("  stay on disk and are never read again.")
    print("=" * 76)
    return 0


if __name__ == "__main__":
    sys.exit(main())
