# Stage 9 — RQ1 / RQ2 results

agentnet 0.10.2 · analysis plan revision 7 · 2026-10-20 12:20 UTC

Every number below is a measurement. Nothing here is a claim about prompts outside the twenty in this corpus, and the renderer refuses to emit wording that would suggest otherwise.

## What was analysed

- **1,359 runs** on **20 prompts** shared by both agents, across **40 of 40** agent × prompt cells.
- Runs per agent: **hermes** 680, **openclaw** 679.
- Runs per cell: 24–40.
- Prompts per class: local_execution 6, web_only 6, web_then_local 8.
- Excluded before any statistic: no task 140.

Claim-carrying features analysed: **9** for RQ1, **11** for RQ2.

Registered but **not measurable from this extraction**, so absent from every table rather than reported as zero: `distinct_nonprovider_asns`, `dominant_asn_byte_fraction`.

Registered and measured but **carrying no claim**, by a documented revision: `new_flows_per_active_min`, `onset_median_ms`.

## The measurement's own noise floor

Computed first, from within-agent within-prompt half-splits, which contain no platform contrast by construction. M_f is the median of the 40 cell p90 values; it selected the resampling before any comparison below was computed.

| feature | M_f | median cell n | cells ≥ 0.147 | resampling | low resolution |
|---|---|---|---|---|---|
| `bytes_down_total` | 0.330 | 38 | 40/40 | two-level | no |
| `bytes_ratio_down_up` | 0.323 | 38 | 40/40 | two-level | no |
| `bytes_up_total` | 0.316 | 38 | 40/40 | two-level | no |
| `distinct_dst_ips` | 0.317 | 38 | 40/40 | two-level | no |
| `iat_down_median_ms` | 0.309 | 38 | 40/40 | two-level | no |
| `longest_gap_s` | 0.250 | 38 | 33/40 | two-level | no |
| `median_flow_duration_s` | 0.315 | 38 | 40/40 | two-level | no |
| `n_flows_tcp` | 0.320 | 38 | 40/40 | two-level | no |
| `nonprovider_bytes_frac` | 0.323 | 38 | 40/40 | two-level | no |
| `pktsize_down_median` | 0.314 | 38 | 40/40 | two-level | no |
| `pktsize_up_median` | 0.313 | 38 | 40/40 | two-level | no |

0 of 11 features have a noise floor at or above 0.33, where the measurement's own variability reaches the small-effect band. Those are flagged, not dropped.

**Read this column with the one beside it.** The floors span 0.080 from lowest to highest, with `longest_gap_s` at 0.250 and `bytes_down_total` at 0.330.

No verdict is drawn from that number alone. A split-half δ is largely a function of how many runs the cell holds, so on a corpus with uniform cell sizes the floors cluster whatever the features are; and a single feature that returns a near-constant value will sit far below the rest, widening the span without any of the others having separated. **Check the low end against the “distinct values” column in the RQ1 table before reading anything into the spread.** What the floors are good for is the scale: they say what magnitude of δ this design produces where no platform contrast exists, and that is what the RQ1 table should be read against.

## RQ1 — platform, within prompt

For each prompt separately, Cliff's δ between **hermes** and **openclaw** runs. A positive δ means hermes runs tend higher on that prompt. The 20 per-prompt values are in `rq1_deltas.csv`; no δ pools runs across prompts.

| feature | median δ | 95% CI | hermes median | openclaw median | distinct values | same direction | verdict |
|---|---|---|---|---|---|---|---|
| `bytes_down_total` | 0.605 | 0.449 … 0.709 | 4.944e+05 | 3.170e+05 | 20 / 20 | 18/20 | **consistent** |
| `iat_down_median_ms` | -0.572 | -0.697 … -0.390 | 0.003040 | 0.003994 | 6 / 15 | 18/20 | **consistent** |
| `bytes_ratio_down_up` | 0.547 | 0.339 … 0.644 | 0.8521 | 0.5269 | 20 / 20 | 18/20 | **consistent** |
| `pktsize_down_median` | 0.324 | 0.176 … 0.453 | 342.6 | 114.2 | 20 / 20 | 19/20 | **consistent** |
| `bytes_up_total` | 0.290 | 0.098 … 0.575 | 7.479e+05 | 4.612e+05 | 20 / 20 | 16/20 | **consistent** |
| `pktsize_up_median` | -0.171 | -0.254 … 0.050 | 369.0 | 1239 | 20 / 17 | 13/20 | reverses |
| `n_flows_tcp` | 0.144 | -0.071 … 0.393 | 35.75 | 29.25 | 20 / 16 | 12/20 | reverses |
| `median_flow_duration_s` | 0.120 | -0.054 … 0.275 | 2.573 | 1.215 | 20 / 20 | 14/20 | mixed |
| `longest_gap_s` | 0.108 | 0.039 … 0.219 | 0 | 0 | 6 / 1 | 17/20 | **consistent** |

**Read δ against the two median columns, never alone.** Cliff's δ is a RANK statistic: it asks how often one agent's runs sit above the other's, and it cannot tell a two-byte difference from a two-megabyte one. A tiny but perfectly consistent gap scores as a large effect. The medians are in the feature's own unit, at prompt level.

**“distinct values”** counts how many different numbers each agent's twenty prompt medians take (hermes / openclaw). A count of 1 means the measurement returned the same value for every prompt in that agent — it is not describing the task, and a δ against it describes the other agent alone. Counts are reported, and nothing is dropped on them.

**Two columns not shown here decide whether a `consistent` verdict means anything**, and both are in `rq1_summary.csv`. `n_at_least_medium` counts prompts reaching the published 0.474 boundary; `n_exceeding_noise_floor` counts prompts where the contrast is larger than what that same cell produces when split against itself. The verdict below counts SIGNS, so a feature can read `consistent` while most of its prompts are negligible in size — those two columns are what expose it.

*Verdicts.* `negligible` = the feature clears the negligible boundary on fewer than a third of the prompts, so it does not separate the two platforms here and its direction is not worth describing. `consistent` = the sign agrees on at least 80% of the prompts with a defined δ. `reverses` = the feature points both ways on a substantial share of prompts, so its median describes no prompt in particular. `mixed` = in between. A feature that reverses is not a platform signature whatever its median — and a median near zero beside a high “at least medium” count is exactly that case, not an absence of difference.

### Collection-period drift, beside the same features

Collection was **blocked, not interleaved** — one agent's runs sit inside the other's window — so platform is confounded with collection period. This control cannot remove that. It measures how much this corpus moves within ONE agent on ONE prompt, latest third against earliest, where no platform contrast exists.

| feature | RQ1 verdict | median drift | p90 drift | platform δ | drift ≥ platform | same direction |
|---|---|---|---|---|---|---|
| `pktsize_down_median` | consistent | 0.364 | 0.566 | 0.324 | **YES** | **yes** |
| `bytes_up_total` | consistent | 0.313 | 0.645 | 0.290 | **YES** | no |
| `iat_down_median_ms` | consistent | 0.281 | 0.533 | -0.572 | no | no |
| `bytes_down_total` | consistent | 0.250 | 0.462 | 0.605 | no | no |
| `median_flow_duration_s` | mixed | 0.233 | 0.671 | 0.120 | **YES** | no |
| `bytes_ratio_down_up` | consistent | 0.191 | 0.582 | 0.547 | no | no |
| `longest_gap_s` | consistent | 0.156 | 0.504 | 0.108 | **YES** | **yes** |
| `n_flows_tcp` | reverses | 0.405 | 0.598 | 0.144 | (yes) | no |
| `pktsize_up_median` | reverses | 0.352 | 0.668 | -0.171 | (yes) | yes |

**Read the flag only on the rows that claim a direction.** A feature whose platform δ is negligible or reverses will show drift ≥ platform for a trivial reason — anything exceeds nearly nothing — so those rows are shown in parentheses and carry no warning. The drift figure itself also has a sampling floor: a third of a cell is a small sample, so a value of roughly this size appears even where nothing is changing.

**4 of the 7 features that claim a direction drift at least as much within one agent as they differ between the two.** For those the platform reading cannot be separated from the collection period in this design, and the results chapter has to say that rather than report a platform difference.

2 of them drift in the SAME DIRECTION as their platform δ. Taken at face value that is the combination worth stating plainly: the later-collected agent would look different for a reason that is not the platform, and the two explanations point the same way.

**But this figure aggregates both agents, and on a blocked collection that mixes two different periods** — if one agent's runs sit nested inside the other's window, “latest third” does not mean the same thing on each side, and the flag over-warns. Splitting `temporal_drift.csv` by agent is the check that settles it: signed drifts pointing in OPPOSITE directions in the two agents cannot be produced by one monotone trend. This report does not perform that split; it is reported separately and must be read before acting on the count above.

Small drift is not proof that a platform result is real. It removes one alternative explanation, and nothing more.

## RQ2 — task type, within platform

One observation is a prompt median; n = 20 per agent, split local_execution 6, web_only 6, web_then_local 8. Run counts do not enter these comparisons.

| feature | ordering · hermes | ordering · openclaw | pairs agreeing | verdict |
|---|---|---|---|---|
| `longest_gap_s` | — | — | 0/3 | undefined |
| `iat_down_median_ms` | — | web_only < web_then_local < local_execution | 2/3 | undefined |
| `bytes_up_total` | local_execution < web_only < web_then_local | local_execution < web_only < web_then_local | 3/3 | **replicates** |
| `bytes_down_total` | local_execution < web_only < web_then_local | local_execution < web_only < web_then_local | 3/3 | **replicates** |
| `bytes_ratio_down_up` | local_execution < web_then_local < web_only | local_execution < web_then_local < web_only | 3/3 | **replicates** |
| `pktsize_up_median` | web_then_local < web_only < local_execution | web_only < local_execution < web_then_local | 1/3 | does_not_replicate |
| `pktsize_down_median` | local_execution < web_then_local < web_only | local_execution < web_then_local < web_only | 3/3 | **replicates** |
| `n_flows_tcp` | local_execution < web_only < web_then_local | local_execution < web_only < web_then_local | 3/3 | **replicates** |
| `median_flow_duration_s` | local_execution < web_only < web_then_local | local_execution < web_only < web_then_local | 3/3 | **replicates** |
| `distinct_dst_ips` | local_execution < web_only < web_then_local | local_execution < web_only < web_then_local | 3/3 | **replicates** |
| `nonprovider_bytes_frac` | local_execution < web_only < web_then_local | local_execution < web_then_local < web_only | 2/3 | partial |

Replication *is* the claim here: with six, six and eight prompts per class, a contrast seen in one agent is a handful of points, and the question worth asking is whether the same ordering appears independently in the other. Per-pair δ values are in `rq2_class_contrasts.csv`.

### RQ2b — complexity

**The gate is closed, and was closed before any behaviour was measured.** Stage 6 found the complexity components that vary are the ones that define `taxonomy_class`, so a relationship between behaviour and complexity cannot be distinguished from a relationship with class. The ρ values in `rq2b_complexity.csv` are descriptive and are reported so a reader is not left wondering; they do not estimate a complexity effect, whatever their size.

## The supplementary test

**Not run.** 6 feature(s) are eligible under the pre-specified rule, but the plan admits at most ONE test and the choice is deliberate, not automatic. Re-run with --sign-test <feature> to spend it; the reason lands in this report.

*Scope, binding on any use of it:* consistency across these 20 tasks; not population-level inference.

## What these numbers do not settle

- The twenty prompts are a fixed, purposively chosen set. Every result above describes behaviour on these prompts, and the renderer refuses wording that would extend it further.
- RQ2 rests on six, six and eight prompts per class. Only large separations are visible at that size, and the design says so in advance rather than discovering it in the viva.
- Complexity cannot be separated from task class in this corpus; the gate was closed by Stage 6, before any behaviour was measured.
- The pre-registered onset metric did not recover application response latency in this capture setup: onset_median_ms resolves a TLS handshake round trip and was demoted to diagnostic at plan revision 4 on measured evidence. That bounds what THAT metric achieved under THESE conditions; it does not establish that no passive method could.
- new_flows_per_active_min was demoted at plan revision 6 on construct validity: its denominator, activity_span_s, was already diagnostic, and the observed rate contrast is dominated by that duration normalisation. The flow count and the span may be reported as context and may not be worded as a difference in how fast either agent opens connections.
- The capture is whole-host, so the non-provider destination population contains traffic this design cannot attribute to the agent. It is reported, never subtracted.
- Corpus limitations carried from the frozen plan: onset metric did not recover response latency, whole host capture, persistent connections across runs, residual unattributed upstream tcp, blocked collection hermes nested in openclaw, mitm covers proxied llm path only.

