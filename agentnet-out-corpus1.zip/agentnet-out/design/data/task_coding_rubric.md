# Task coding rubric

Twenty prompts, coded from the **instruction text only**. Never from a run,
a log, an outcome, or anything observed on the wire. If you find yourself
opening `out/` to decide a value, stop: that value is not admissible.

Code blind to results, and ideally twice — by two people, or by you a week
apart — recording agreement per factor in `task_properties.csv`.

## Headline taxonomy (proposed, retained)

Exactly one class per task. Assigned from the instruction, not from behaviour.

| Class | Assign when the instruction... |
|---|---|
| `web_only` | requires retrieving external content and requires no local execution |
| `local_execution` | requires running or writing something locally and requires no retrieval |
| `web_then_local` | requires both, with the local part consuming what was retrieved |

If a task requires both but the local part does **not** consume the retrieved
material, record it and raise it — it is neither `web_then_local` nor cleanly
either of the others, and the taxonomy may need a fourth class.

## Capability factors (descriptive metadata, underneath the taxonomy)

| Factor | Type | Code 1 / the value when the instruction... |
|---|---|---|
| `requires_web_fetch` | bool | names or implies retrieving external content |
| `requires_local_execution` | bool | requires running or writing something locally |
| `has_data_dependency` | bool | has a later step consuming an earlier step's output |
| `requires_iteration` | bool | implies repeat-until, check-and-retry, or "keep going until" |
| `n_required_fetches` | ordinal | count of distinct sources the instruction demands (not the number actually fetched) |
| `has_grounding_instruction` | bool | tells the agent to verify or cite against a source |
| `n_explicit_steps` | int | count of enumerated steps in the prompt (0 if unenumerated) |
| `named_domains_count` | int | count of literal hostnames appearing in the prompt |

`named_domains_count` is recorded for the audit and is **never** a feature: a
hostname list drawn from task text is structural leakage of the task label.

## Prohibited inputs to every value above

Runtime. Packet or byte counts. Observed tool calls. Model turns.
Success or failure. Number of pages actually fetched. Any run-level table.

Complexity is a property of the instruction. If it can only be known after the
run, it is an outcome, and it belongs in the results, not in the coding.

## Before any factor is argued to be primary

Stage 6 must first emit:

- `task_factor_matrix.csv` — all 20 tasks × every factor, plus the headline
  class, printed verbatim in the report.
- `factor_contrast_support.csv` — for each proposed contrast: independent
  tasks on each side, the cross-tab against the headline class, and whether
  the contrast is separable from the taxonomy or merely a relabelling of it.

A contrast that reproduces the class split carries no independent evidence.
