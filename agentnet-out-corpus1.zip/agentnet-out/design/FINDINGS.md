# Findings so far

What has actually been measured on the OpenClaw / Hermes corpus, what it
means, and what it does not mean. Every number below came out of a command
run against the real corpus; nothing here is an estimate or an expectation.

**Provenance matters in this document.** Results are marked:

- **[pipeline]** — written by the package to a file with a SHA-256 in
  `run_manifest.json`, re-derivable by re-running one command.
- **[ad hoc]** — produced by a one-off script against pipeline outputs.
  Correct, but not yet reproducible by a command. Where a finding matters,
  the fix is to fold the check into a stage, not to cite the terminal.

Stage 5 exists precisely because several important checks below started life
as **[ad hoc]** and needed to become **[pipeline]**.

---

## 1. Corpus structure

**[pipeline]** `agentnet index`

| | |
|---|---|
| Runs discovered | 3,499 |
| Status OK | 3,499 (every run has both `http_log.log` and `merged.pcap`) |
| OpenClaw | 2,499 |
| Hermes | 1,000 |
| `exp_num` consistent with round-robin(20) | yes |

Matches the existing pipeline's own count exactly, so the index is not
disagreeing with prior work.

**Collection was blocked, not interleaved** — OpenClaw ×1,999, then Hermes
×1,000, then OpenClaw ×500, split at exp2000. Hermes is *nested inside* the
OpenClaw window. Platform is therefore confounded with collection period, but
the bracketing OpenClaw blocks allow drift to be measured directly with
platform and task held constant. That is a better position than a clean
before/after split would have given.

---

## 2. Task identity

**[pipeline]** `agentnet http-parse` · **[pipeline]** `agentnet tasks`

20 distinct tasks, **shared by both agents**, zero single-agent tasks. Every
one of the 3,499 runs yielded its task by the `Task:` marker — no fallbacks,
no parse failures.

Run counts per task: **OpenClaw 125 each for 19 tasks and 124 for one;
Hermes 50 each.** The single 124 is exactly the round-robin remainder — 2,499
does not divide by 20 — so the imbalance is the design showing through rather
than a missing run.

### 2.1 Three ways the task key could have been wrong

Each of these was found by inspecting real records, and each would have
corrupted a result rather than crashing.

**The user prompt is not the task.** It is a harness preamble followed by
`Task: <text>`, and the preamble names *the agent's own workspace directory*
(`…/agent_workspace/hermes` against `…/agent_workspace/openclaw`). Grouping on
the raw message would have produced 40 task groups with **no overlap between
the agents**, silently turning every paired RQ1 comparison into a comparison
of disjoint sets.

**One agent prefixes a per-run timestamp.** OpenClaw's prompt opens with
`[Fri 2026-08-07 11:34 GMT+10]`. Left in the key, every run would have hashed
to its own task — 2,499 task groups.

**The two agents encode `content` differently.** Hermes sends a plain string;
OpenClaw sends the structured multi-part form
`[{"type": "text", "text": …}]`. The first parser read only the string form
and treated the rest as absent, which emptied the task for all 2,499 OpenClaw
runs — while `parse_status` reported `ok` for all 3,499, because the check
asked whether the task was *missing* rather than *empty*. The only symptom was
a secondary count reading `shared by all agents: 0`.

All three are now handled, regression-tested, and reported per agent rather
than pooled.

### 2.2 Task-set composition

**[ad hoc]** The 20 prompts share subject matter but vary systematically in
structure. Three tasks concern the `requests` library, but differ on fetch
count (1, 2, 2), data dependency (no, no, **yes** — one task scrapes a version
from PyPI and uses it to build the next URL), and whether local execution is
required. Surface similarity, structural variety.

`tasks.csv` now reports a nearest-neighbour text similarity per task so
near-duplicate prompts are visible rather than discovered late. Nothing is
ever merged on it.

---

## 3. HTTP ground truth

**[pipeline]** `agentnet http-parse` → 29,438 exchanges over 3,499 runs
(≈8.4 per run).

`parsed_response` has **four** shapes in the corpus: `list` 25,056 (streamed
SSE), `dict` 2,829 (non-streamed JSON), `str` 1,329 (HTML error pages), and
224 requests with no response record at all (0.8%). The one redacted sample
contained only two of these. Recording the shape instead of assuming it is
what kept the fourth from being a crash.

---

## 4. The MITM ↔ PCAP join

**[pipeline]** `agentnet align`

| | |
|---|---|
| Exchanges matched on the exact five-tuple | **29,438 / 29,438 (100.00%)** |
| Inference calls matched | 25,587 / 25,587 (100.00%) |
| Matches on the upstream leg | all of them |
| Exceptions (unmatched, ambiguous, wrong leg) | zero |

The mitmproxy record is the **upstream socket**, carrying the same
`(host/LAN IP, port, provider IP, 443)` the capture sees on the upstream leg.
This reproduces the prior validation exactly, on the rebuilt pipeline.

There is deliberately **no approximate matcher** — no nearest-port, no
time-window fallback, no "there was only one flow so it must be that one". The
join exists so Stage 8 can ask whether a passive measurement agrees with
ground truth; a matcher that relaxed its key until things lined up would
manufacture that agreement.

**Essentially no connection reuse.** 29,438 exchanges matched 29,436 distinct
flows — about one TCP connection per API call. Flow count and request count
are nearly the same quantity for the proxied traffic, which matters when
interpreting any flow-count measure.

---

## 5. The finding that changed the interpretation

**[pipeline]** coverage · **[ad hoc]** the SNI breakdown behind it

Every MITM exchange joined a flow, yet only **40.43%** of upstream TCP flows
(29,436 of 72,807) carried one. The remaining ~43,000 break down as:

| Population | Count | Evidence |
|---|---|---|
| Non-443 host services | 3,363 | ports 5223 (Apple push), 4070 (Spotify), 853 (DNS-over-TLS), 5228 (Google) |
| Port 443, SNI present | 24,858 | see below |
| Port 443, no SNI | 15,150 | no ClientHello captured → connection predates the run's capture |

The SNI names settle what the 24,858 are. The top of that list is *the task
targets*: `raw.githubusercontent.com` (3,204), `www.python.org` (1,757),
`github.com` (1,579), `api.github.com` (1,400), `html.duckduckgo.com` (1,397),
`pypi.org` (567), `nodejs.org` (483), `wttr.in` (300), `registry.npmjs.org`
(274), `arxiv.org` (240). Mixed in with genuine background:
`main.vscode-cdn.net`, `gateway.icloud.com`, `ocsp2.apple.com`,
`teams.events.data.microsoft.com`.

### 5.1 The confirming test

A prediction stated before looking: if these are agent fetches, a task-target
host should appear in *its own task's* runs and nowhere else, while a
background host should be spread across all twenty.

| SNI | Distinct tasks | Result |
|---|---|---|
| `wttr.in` | **1** | all 300 flows in the weather task |
| `arxiv.org` | **1** | all 240 in the arXiv task |
| `registry.npmjs.org` | 6 | 93% in the express/npm task |
| `gateway.icloud.com` | **20** | spread evenly — background |

### 5.2 What this establishes

**MITM ground truth is complete for the proxied LLM API path and incomplete
for agent network activity as a whole.** The agents' web and tool fetches did
not traverse mitmproxy. They are passively visible in the capture with no
corresponding ground-truth record.

The analysed universe is therefore three populations, not two:

1. **LLM API calls via the proxy** — 29,436 flows, fully ground-truthed.
2. **Direct web/tool fetches** — agent behaviour, passively visible, no ground
   truth.
3. **Host background** — not agent traffic. The capture is whole-host.

### 5.3 What must not be concluded from it

- **The coverage figure is not an agent/background split.** 40.43% is coverage
  *of the proxied subset*. Reporting it as "40% agent, 60% noise" would be
  wrong in both directions.
- **A high match rate does not validate the passive features.** It establishes
  only that both sources describe the same connections — the precondition for
  the Stage 8 comparisons, not a result.
- **Onset validation is scoped.** Stage 8 can validate `onset_median_ms`
  against MITM TTFB *on the proxied subset only*. Nothing validates onset for
  direct fetches.

---

## 6. Revision 7 — the resulting design change

Deliberately narrow, and recorded in the frozen `analysis_plan.py`.

| | Before (rev 6) | After (rev 7) |
|---|---|---|
| `distinct_dst_ips` | secondary context, both RQs | **primary for RQ2**, secondary for RQ1 |
| `nonprovider_bytes_frac` | secondary context, both RQs | **primary for RQ2**, secondary for RQ1 |
| ASN measures | secondary context | unchanged |
| Feature count | 15 | 15 |

The promotion is for RQ2 because these measure exactly the network-footprint
change a web-based task produces. They stay context for RQ1 because
whole-host background can differ between the two agents' collection periods
and so cannot carry a platform claim.

No feature was added. The registry gained a per-question claim scope so one
measurement can carry different weight for different questions. The exception
is **closed**: the frozen plan names the two features it covers, and a guard
fails the build if the registry drifts from that list in either direction —
promoting an ASN measure passes the layer check and fails this one.

Three prohibitions carried forward explicitly:

- Literal task hostnames never enter the feature matrix. The task-to-host map
  is derived from task identity, so predicting the task from it would be
  predicting the label from a restatement of it — the same reason
  `named_domains_count` is recorded for the audit and never used.
- Background is **referenced, not subtracted**. Local-execution tasks give an
  empirical picture of the footprint when no fetching is required; that
  reference is reported, and features are never cleaned using task labels.
- Literal ASN identity stays out of behavioural inference.

---

## 7. Measurement limitations, as measured

1. **Whole-host capture.** ARP, mDNS, Spotify, iCloud, VS Code updates. Host
   background cannot be perfectly separated from agent traffic passively.
2. **MITM covers the proxied LLM path only.** §5.
3. **Persistent connections across run boundaries.** 15,150 unmatched 443
   flows have no ClientHello in their capture, and `onset_median_ms` is
   computed only where the handshake was observed — `onset_defined_frac` is
   reported beside it always.
4. **Blocked collection.** Platform confounded with collection period;
   measurable via the bracketing OpenClaw blocks.
5. **mitmproxy terminates TLS.** Upstream-leg behaviour is agent+proxy
   composite. TLS fingerprints would describe the proxy, so they are not
   measured.
6. **Task-set diversity.** 20 prompts, several sharing subject matter. The
   nearest-neighbour similarity in `tasks.csv` quantifies it.

---

## 8. What is still open

- **The task coding.** `task_coding_sheet.csv` is written blank. The 20
  prompts need coding into `web_only` / `local_execution` / `web_then_local`
  plus the capability factors, **from instruction text alone and blind to
  results**. This is the input to Stage 6 and is deliberately not automated —
  coding them after seeing the traffic is exactly what the blind-coding rule
  exists to prevent.
- **Stages 6–9.** Taxonomy, feature matrix, validation, analysis.
- **No behavioural claim has been made.** Nothing here says whether the two
  agents differ, whether any task type has a network signature, or whether any
  effect is significant. Those sentences get written after Stage 9 runs.

---

## Reproducing this

```bash
export AGENTNET_OUT=/Volumes/MINT/agentnet-out
agentnet index --root /Volumes/MINT/collection --expect-runs 3499 --hash none
agentnet http-parse --root /Volumes/MINT/collection
agentnet probe
agentnet pcap-extract --root /Volumes/MINT/collection --resume
agentnet align
agentnet tasks --expect-tasks 20
agentnet verify
```

`agentnet verify` re-hashes every output against `run_manifest.json`, so a
number in this document can be traced to the inputs that produced it.
